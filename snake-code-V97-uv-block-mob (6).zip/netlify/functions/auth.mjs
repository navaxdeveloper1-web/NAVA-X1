import crypto from 'node:crypto';

// Client ID Google (bukan rahasia). Bisa ditimpa lewat variabel CLAUDE_GOOGLE.
const CID = process.env.CLAUDE_GOOGLE || '521025928886-17j929um7lagsej968fnrqojmnevbms9.apps.googleusercontent.com';

const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
const store = async n => globalThis.__xaStore ? globalThis.__xaStore(n) : (await import('@netlify/blobs')).getStore(n);
const scrypt = (pw, salt) => new Promise((res, rej) => crypto.scrypt(pw, salt, 64, (e, k) => e ? rej(e) : res(k)));
const same = (a, b) => a.length === b.length && crypto.timingSafeEqual(a, b);

async function secret() {
  if (process.env.XA_SECRET) return process.env.XA_SECRET;
  const c = await store('xa-config');
  let s = await c.get('secret');
  if (!s) { s = crypto.randomBytes(32).toString('hex'); await c.set('secret', s); }
  return s;
}
async function sign(email) {
  const p = Buffer.from(JSON.stringify({ e: email, x: Date.now() + 30 * 864e5 })).toString('base64url');
  return p + '.' + crypto.createHmac('sha256', await secret()).update(p).digest('base64url');
}
async function verify(t) {
  const [p, m] = String(t || '').split('.');
  if (!p || !m) return null;
  const g = crypto.createHmac('sha256', await secret()).update(p).digest('base64url');
  if (!same(Buffer.from(g), Buffer.from(m))) return null;
  try { const d = JSON.parse(Buffer.from(p, 'base64url')); return d.x > Date.now() ? d.e : null; } catch (e) { return null; }
}
const pub = u => ({ email: u.email, name: u.name, pic: u.pic || '', hasPw: !!u.hash });
const k = e => encodeURIComponent(e);

// ---- aset: jenis file, validasi isi, kode ----
const ASSET_MAX = 5000000;
const ASSET_TYPES = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', apng: 'image/png', jfif: 'image/jpeg', bmp: 'image/bmp', avif: 'image/avif', ico: 'image/x-icon', svg: 'image/svg+xml', tif: 'image/tiff', tiff: 'image/tiff', glb: 'model/gltf-binary', gltf: 'model/gltf+json', obj: 'text/plain; charset=utf-8', stl: 'application/octet-stream', fbx: 'application/octet-stream', json: 'application/json; charset=utf-8' };
const head = (b, s, o = 0) => b.subarray(o, o + s.length).toString('latin1') === s;
function assetOk(e, b) {
  if (e === 'png' || e === 'apng') return b[0] === 0x89 && head(b, 'PNG', 1);
  if (e === 'bmp') return head(b, 'BM');
  if (e === 'avif') return head(b, 'ftyp', 4);
  if (e === 'ico') return b[0] === 0 && b[1] === 0 && b[2] === 1 && b[3] === 0;
  if (e === 'svg') return /<svg[\s>]/i.test(b.subarray(0, 2000).toString('utf8'));
  if (e === 'tif' || e === 'tiff') return head(b, 'II*\0') || head(b, 'MM\0*');
  if (e === 'jpg' || e === 'jpeg' || e === 'jfif') return b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
  if (e === 'gif') return head(b, 'GIF8');
  if (e === 'webp') return head(b, 'RIFF') && head(b, 'WEBP', 8);
  if (e === 'glb') return head(b, 'glTF');
  if (e === 'gltf') { try { const j = JSON.parse(b.toString('utf8')); return !!(j && j.asset); } catch (x) { return false; } }
  if (e === 'obj') return !b.subarray(0, 2000).includes(0);
  if (e === 'stl') return head(b, 'solid') || (b.length >= 84 && b.length === 84 + 50 * b.readUInt32LE(80));
  if (e === 'json') { try { const j = JSON.parse(b.toString('utf8')); return !!j && typeof j === 'object' && (!!j['minecraft:geometry'] || Object.keys(j).some(k => k.startsWith('geometry.')) || (!!j.animations && typeof j.animations === 'object')); } catch (x) { return false; } }
  if (e === 'fbx') return head(b, 'Kaydara FBX Binary') || head(b, '; FBX');
  return false;
}
const parseCode = c => { const m = /^(?:\/\/:)?(\d{10})$/.exec(String(c || '').trim()); return m ? m[1] : null; };
// tanggal kode memakai WIB (UTC+7): nomor urut mulai lagi 0001 bila tahun, bulan, atau tanggal berbeda
const wibDay = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(2, 10).replace(/-/g, '');

export default async req => {
  const path = new URL(req.url).pathname;
  const auth = () => verify((req.headers.get('authorization') || '').replace(/^Bearer /, ''));

  // ---- proyek ----
  if (path.endsWith('/proj')) {
    const em = await auth();
    if (!em) return J({ error: 'Sesi berakhir, silakan masuk lagi' }, 401);
    const ps = await store('xa-proj');
    if (req.method === 'GET') return J({ project: (await ps.get(k(em), { type: 'json' })) || null });
    if (req.method === 'PUT') {
      const t = await req.text();
      if (t.length > 900000) return J({ error: 'Proyek terlalu besar' }, 413);
      let p; try { p = JSON.parse(t); } catch (e) { return J({ error: 'Data tidak valid' }, 400); }
      if (!p || typeof p.files !== 'object') return J({ error: 'Data tidak valid' }, 400);
      await ps.setJSON(k(em), p);
      return J({ ok: true });
    }
    return J({ error: 'Metode tidak didukung' }, 405);
  }

  // ---- aset 3D / gambar (kode //:YYMMDDNNNN) ----
  if (path.endsWith('/asset')) {
    const as = await store('xa-asset');
    const q = new URL(req.url).searchParams;
    if (req.method === 'GET') {
      if (q.get('list')) {
        const em = await auth();
        if (!em) return J({ error: 'Sesi berakhir, silakan masuk lagi' }, 401);
        const l = (await (await store('xa-asset-user')).get(k(em), { type: 'json' })) || [];
        return J({ assets: l });
      }
      const code = parseCode(q.get('code'));
      if (!code) return J({ error: 'Kode aset tidak valid. Format: //:YYMMDDNNNN (contoh //:2610160001)' }, 400);
      const meta = await as.getMetadata(code);
      const data = meta ? await as.get(code, { type: 'arrayBuffer' }) : null;
      if (!data) return J({ error: 'Aset //:' + code + ' tidak ditemukan' }, 404);
      return new Response(data, { status: 200, headers: {
        'content-type': ASSET_TYPES[meta.metadata.ext] || 'application/octet-stream',
        'cache-control': 'public, max-age=31536000, immutable',
        'x-content-type-options': 'nosniff',
        'content-security-policy': "sandbox; default-src 'none'",
        'access-control-allow-origin': '*',
        'cross-origin-resource-policy': 'cross-origin'
      } });
    }
    if (req.method === 'POST') {
      const em = await auth();
      if (!em) return J({ error: 'Akun tamu tidak bisa mengunggah aset, silakan masuk dulu' }, 401);
      let name = ''; try { name = decodeURIComponent(req.headers.get('x-asset-name') || ''); } catch (e) {}
      name = name.replace(/[\\/\x00-\x1f]/g, '').trim().slice(0, 100);
      const ext = (/\.([A-Za-z0-9]{2,5})$/.exec(name) || [])[1];
      const e = ext && ext.toLowerCase();
      if (!e || !ASSET_TYPES[e]) return J({ error: 'Jenis file tidak didukung. Boleh: ' + Object.keys(ASSET_TYPES).join(', ') }, 400);
      const buf = Buffer.from(await req.arrayBuffer());
      if (buf.length < 8) return J({ error: 'File kosong' }, 400);
      if (buf.length > ASSET_MAX) return J({ error: 'File terlalu besar (maksimal 5 MB)' }, 413);
      if (!assetOk(e, buf)) return J({ error: 'Isi file tidak cocok dengan ekstensi .' + e }, 400);
      const day = wibDay(), seq = await store('xa-asset-seq');
      let n = parseInt(await seq.get(day), 10) || 0;
      for (let t = 0; t < 200; t++) {
        n++;
        if (n > 9999) return J({ error: 'Batas 9999 aset per hari sudah tercapai, coba lagi besok' }, 429);
        const code = day + String(n).padStart(4, '0');
        if (await as.getMetadata(code)) continue;
        const r = await as.set(code, buf, { metadata: { ext: e, name, owner: em, t: Date.now() }, onlyIfNew: true });
        if (r && r.modified === false) continue;
        try { await seq.set(day, String(n)); } catch (x) {}
        const us = await store('xa-asset-user'), l = (await us.get(k(em), { type: 'json' })) || [];
        l.unshift({ code: '//:' + code, name, size: buf.length, t: Date.now() });
        try { await us.setJSON(k(em), l.slice(0, 500)); } catch (x) {}
        return J({ ok: true, code: '//:' + code, name, size: buf.length });
      }
      return J({ error: 'Gagal mendapatkan nomor aset, coba lagi' }, 503);
    }
    return J({ error: 'Metode tidak didukung' }, 405);
  }

  // ---- library ----
  if (path.endsWith('/lib')) {
    const ls = await store('xa-lib');
    const RES = ['c', 'game', 'main'];
    if (req.method === 'GET') {
      const name = String(new URL(req.url).searchParams.get('name') || '').trim();
      if (!/^[A-Za-z0-9_]{1,40}$/.test(name)) return J({ error: 'Nama library tidak valid' }, 400);
      const l = await ls.get(name.toLowerCase(), { type: 'json' });
      if (!l) return J({ error: 'Library "' + name + '" tidak ditemukan' }, 404);
      return J({ lib: { name: l.name, rules: l.rules, by: l.by || '', updated: l.updated } });
    }
    if (req.method === 'PUT') {
      const em = await auth();
      if (!em) return J({ error: 'Akun tamu tidak bisa mengunggah library, silakan masuk dulu' }, 401);
      const t = await req.text();
      if (t.length > 40000) return J({ error: 'Library terlalu besar' }, 413);
      let b; try { b = JSON.parse(t); } catch (e) { return J({ error: 'Data tidak valid' }, 400); }
      const name = String((b && b.name) || '');
      if (!/^[A-Za-z0-9_]{1,40}$/.test(name)) return J({ error: 'Nama library tidak valid (huruf, angka, garis bawah, maksimal 40)' }, 400);
      if (RES.includes(name.toLowerCase())) return J({ error: 'Nama library "' + name + '" dicadangkan karena library bawaan SNAKE' }, 400);
      const rs = b.rules;
      const okp = p => Array.isArray(p) && p.length === 2 && p.every(x => typeof x === 'string' && x.length >= 1 && x.length <= 100 && !x.includes('\n'));
      if (!Array.isArray(rs) || rs.length < 1 || rs.length > 50 || !rs.every(r => r && typeof r.n === 'string' && /^[A-Za-z_]\w{0,39}$/.test(r.n) && Array.isArray(r.pairs) && r.pairs.length === 2 && r.pairs.every(okp)))
        return J({ error: 'Isi library tidak valid: tiap sintaks harus punya tepat dua pasangan (pembuka dan penutup)' }, 400);
      const key = name.toLowerCase();
      const old = await ls.get(key, { type: 'json' });
      if (old && old.owner !== em) return J({ error: 'Nama library "' + name + '" sudah dipakai pengguna lain' }, 409);
      const u = await (await store('xa-users')).get(k(em), { type: 'json' });
      await ls.setJSON(key, { name, rules: rs.map(r => ({ n: r.n, pairs: r.pairs.map(p => [p[0], p[1]]) })), owner: em, by: (u && u.name) || '', updated: Date.now() });
      return J({ ok: true, name, rules: rs.length });
    }
    return J({ error: 'Metode tidak didukung' }, 405);
  }

  // ---- akun ----
  if (req.method !== 'POST') return J({ error: 'Metode tidak didukung' }, 405);
  let b; try { b = await req.json(); } catch (e) { return J({ error: 'Data tidak valid' }, 400); }
  const users = await store('xa-users');
  const get = e => users.get(k(e), { type: 'json' });
  const put = u => users.setJSON(k(u.email), u);
  const out = async (u, x) => J({ token: await sign(u.email), user: pub(u), ...x });
  const em = String(b.email || '').trim().toLowerCase();
  const pw = String(b.password || '');
  const setPw = async u => { u.salt = crypto.randomBytes(16).toString('hex'); u.hash = (await scrypt(pw, u.salt)).toString('hex'); };

  if (b.a === 'google') {
    let d = {};
    try { const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(b.credential || '')); d = r.ok ? await r.json() : {}; } catch (e) {}
    if (d.aud !== CID || !d.email || !(d.email_verified === true || d.email_verified === 'true')) return J({ error: 'Login Google gagal diverifikasi' }, 401);
    const e = d.email.toLowerCase();
    let u = await get(e) || { email: e, created: Date.now() };
    // email dimiliki lewat Google: akun yang didaftarkan orang lain dengan email ini tanpa verifikasi di-reset passwordnya
    if (!u.verified) { delete u.hash; delete u.salt; u.verified = true; }
    u.name = u.name || d.name || e.split('@')[0];
    u.pic = d.picture || u.pic || '';
    await put(u);
    return out(u, { gsub: d.sub });
  }
  if (b.a === 'register') {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em) || em.length > 200) return J({ error: 'Email tidak valid' }, 400);
    if (pw.length < 8 || pw.length > 128) return J({ error: 'Password minimal 8 karakter' }, 400);
    if (await get(em)) return J({ error: 'Email sudah terdaftar, silakan masuk' }, 409);
    const u = { email: em, name: String(b.name || em.split('@')[0]).slice(0, 60), created: Date.now(), verified: false };
    await setPw(u); await put(u);
    return out(u);
  }
  if (b.a === 'login') {
    const u = em ? await get(em) : null;
    if (u && !u.hash) return J({ error: 'Akun ini belum punya password. Masuk dengan Google di web, lalu buat password di menu akun.' }, 401);
    const ok = u && same(Buffer.from(u.hash, 'hex'), await scrypt(pw, u.salt));
    if (!ok) return J({ error: 'Email atau password salah' }, 401);
    return out(u);
  }
  const me = await auth();
  if (!me) return J({ error: 'Sesi berakhir, silakan masuk lagi' }, 401);
  if (b.a === 'setpw') {
    if (pw.length < 8 || pw.length > 128) return J({ error: 'Password minimal 8 karakter' }, 400);
    const u = await get(me);
    if (!u) return J({ error: 'Akun tidak ditemukan' }, 404);
    await setPw(u); await put(u);
    return J({ ok: true });
  }
  if (b.a === 'me') { const u = await get(me); return u ? J({ user: pub(u) }) : J({ error: 'Akun tidak ditemukan' }, 404); }
  return J({ error: 'Aksi tidak dikenal' }, 400);
};

export const config = { path: ['/api/auth', '/api/proj', '/api/lib', '/api/asset'] };
