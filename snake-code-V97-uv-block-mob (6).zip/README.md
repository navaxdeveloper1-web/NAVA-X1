# SNAKE Code (khusus Hydrogen X)

Editor gaya VS Code khusus bahasa Hydrogen X (.hx). Tanpa login: proyek dan aset tersimpan di penyimpanan HP.

## Isi
- index.html : editor + translator Hydrogen X + dokumentasi Hydrogen X + contoh .hx
- netlify/functions/auth.mjs : server akun, penyimpanan proyek, dan aset (/api/auth, /api/proj, /api/asset)
- package.json : dependensi @netlify/blobs
- netlify.toml : konfigurasi Netlify
- COPYRIGHT-DAN-MEREK.md : pernyataan hak cipta dan merek
- docs/*.md : dokumentasi Hydrogen X, satu file per topik (01-mulai, 02-item, 03-item-class, 04-blok, 05-mob, dst.; salinan teks dari editor)
- test/hydrogenx.test.mjs : tes translator Hydrogen X
- test/asset.test.mjs : tes server aset (kode //:, reset harian, validasi file)
- test/plane.hx : contoh add-on pesawat (memakai aset //: milik pembuat)

## Tanpa login
Tidak ada akun, Google, atau server untuk menyimpan data. Semua fitur langsung bisa dipakai:
- Proyek tersimpan otomatis di penyimpanan browser/HP (localStorage). Proyek lama dari akun yang pernah masuk di perangkat ini diambil otomatis.
- Aset 3D dan gambar (kode `//:YYMMDDNNNN`) tersimpan di penyimpanan HP (IndexedDB), maksimal 5 MB per file. Unggah lewat File > Upload Asset, Ctrl+Shift+P > Assets, atau terminal SNAKE `/Upload asset`; daftar lewat `/assets`. Kode dipakai di `asset://:ID`. Nomor urut mulai 0001 lagi tiap tanggal (WIB).
- Aset hanya ada di perangkat yang mengunggahnya. Menghapus data situs di browser ikut menghapus proyek dan aset.
- Kode `//:` yang tidak ada di HP dicoba diambil dari `/api/asset?code=` bila situs di-deploy di Netlify (opsional, untuk aset publik).

## Deploy
Cukup situs statis: unggah `index.html` (dan `logo.png`) ke hosting apa saja. Folder `netlify/` dan `package.json` hanya dibutuhkan bila ingin aset publik lewat server dan tidak wajib.

## Hydrogen X (.hx)
(V72: kondisi OR memakai ===, deklarasi {user} dan {Custom}, destroy, destroying bed, poin, user_N.mode. V70: crafting, menu_creative, fly/move/lead, kursi, state mob/pemain, klik, icon, costum, setup dan icon_mod sudah diterjemahkan.)
Tulis kode SLAP Minecraft Mode di file `.hx`, tekan Run (F5) atau tombol Upload: browser mengunduh `nama.mcaddon` (Behavior Pack + Resource Pack) yang langsung bisa dibuka Minecraft Bedrock. Translator tertanam di `index.html` (`<script id="hydrogenx">`), mengambil aset `//:` dari `/api/asset`, dan mengenali png / `.geo.json` / `.animation.json` dari isinya (server kini menerima `.json` model/animasi Bedrock). Aset yang hilang diganti kotak dan warna polos bawaan. Lihat folder docs/ (mulai dari docs/01-mulai.md) untuk fitur, batasan, dan perbedaan dari spesifikasi V2.2.

- V94: bom `nuclier`: `if(flint_and_steel == nuclier){ wait:6 second / boom:on / radius:3x3x3 }`; korek memakai nama resmi Minecraft Bedrock bahasa Inggris (`flint_and_steel`), bom berkedip seperti TNT bawaan, radius sampai 5000 x 5000 (dikerjakan bertahap per chunk, hanya chunk yang termuat). Lihat docs/04-blok.md.
- V93: `{food` (makanan: `saturation:+2`, animasi makan bawaan Minecraft, tanpa if/else); docs/02-item.md.
- V93: `{block` (sama dengan `{item_block`) dan `item_drop:` untuk menentukan barang yang jatuh saat blok custom dihancurkan: `if(diamond_merah == destroy){ item_drop:diamond_merah_ingot }` (docs/04-blok.md).
- V92: tekstur blok Minecraft bawaan bisa diganti dengan `{obsidian models://:ID }` (docs/04-blok.md).
- V91: variabel `int` (maks 14 digit), `double` (maks 15 digit), `auto`; `+=`, `-=`, `*=`, `/=`, `++`, `--`; `out#"teks" + variabel`. Lihat docs/14-variabel.md.
- V89: `class:` item (sword, axe, pick_axe, shovel, hoe, armor) yang bisa diupgrade level demi level dengan Buku Sihir (`hx:buku_sihir`). Lihat docs/03-item-class.md.

## Fitur translator (digabung dari V4)
- Terminal berbahasa Inggris penuh (error, warning, progres, Asset terminal).
- `models://`, `icon_item://`, `start-animation://` (sekali), `animation-true-start://` (berulang); sintaks lama tetap diterima.
- Blok `[ ... ]`, `user == touch.nama_blok`, animasi pemain, `effect:off` tanpa nama.
- Perbaikan bug: ikon item (`textures.default`), fungsi `onClick` kosong, efek `off` yang menghapus efek ramuan, `min_engine_version` BP/RP.
- Kondisi wajib memakai `==`; tanpa `==` ditolak dengan galat dan nomor baris.
- Mob dari gambar png saja: model bulat 3D dari siluet gambar (`shape:round`, bawaan) atau papan kardus datar (`shape:flat`).
- Skin Minecraft (png 64x64, 64x32, atau kelipatannya): mob otomatis memakai model manusia (kepala, badan, tangan, kaki, lapisan luar) plus animasi jalan; `shape:slim` untuk lengan ramping, `shape:humanoid`/`round`/`flat` untuk memaksa bentuk. JPG diubah ke png otomatis di editor.
- `if(pedang == attack){ attack_effect: poison 5s }`: yang dipukul item itu terkena effect resmi Minecraft (nama tidak resmi ditolak; durasi bawaan 10 detik).
- Tingkat effect: `attack_effect: poison 5s level 2` (level 1 = biasa; tanpa durasi: `attack_effect: poison level 3`).
