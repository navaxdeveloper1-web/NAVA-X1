# Mulai dan aturan umum (Hydrogen X)

Versi translator 0.3 untuk spesifikasi Hydrogen X V2.2 dan dokumen Unimplemented Features. File berekstensi `.hx`. Tekan Run (F5) atau tombol Upload (panah atas): kode diterjemahkan dan browser mengunduh file `nama.mcaddon` yang bisa dibuka Minecraft Bedrock. Buat file baru berakhiran `.hx` untuk mendapat kerangka awal.

## Dokumentasi terpisah
Setiap topik punya dokumen sendiri supaya mudah dicari:
- `02-item.md` Item: properti, crafting, ikon, model 3D, senjata, destroying
- `03-item-class.md` Class item (sword, pick_axe, armor, dll.) dan Buku Sihir
- `04-blok.md` Blok custom (`{item_block`)
- `05-mob.md` Mob: properti, terbang, kursi, bentuk dari png dan skin
- `06-aset.md` Aset kode `//:` dan format gambar/model
- `07-animasi.md` Animasi mob dan pemain
- `08-kondisi.md` Kondisi if / elif / else, klik, attack, touch, efek
- `09-menu.md` Jendela menu
- `10-pemain-bed.md` Pemain, Custom, bed (Bedwars)
- `11-setup.md` Setup add-on (versi, deskripsi, ikon)
- `13-command.md` Perintah chat (`{command`, `word ==`, `out#`)
- `14-variabel.md` Variabel `int`, `double`, `auto`, `+=`, `-=`, dan `out#` dengan variabel
- `12-perbedaan.md` Perbedaan dari spesifikasi dan batasan

## Memasang di Minecraft
- Buka file `.mcaddon` (ketuk di HP, klik dua kali di Windows). Minecraft mengimpor Behavior Pack dan Resource Pack sekaligus.
- Buat dunia baru atau edit dunia, aktifkan kedua pack (`nama_BP` dan `nama_RP`).
- Item: `/give @a hx:nama_item 1`. Mob: `/summon hx:nama_mob` atau telur spawn di inventory kreatif.
- Bila ingin berkas `.zip`, ganti ekstensi `.mcaddon` menjadi `.zip` (isinya sama). Menu Run > Unduh Add-on sebagai .zip juga tersedia.

## Deklarasi dasar

```
{mob_hostile
    name_tag:big_zombie
    models://:2610160005
    animation-true-start://:2610160006
    hp:60 hp
    damage:+6
}
```

Kategori: `mob`, `mob_hostile`, `mob_netral`, `mob_adaptive`, `item`, `asset`. Semua wajib `name_tag:` (huruf kecil, angka, `_`).

- Aturan koma: semua properti berkoma atau semuanya tanpa koma. Campuran ditolak dengan nomor baris. Baris `crafting:` tidak ikut diperiksa karena nilainya sendiri berkoma.
