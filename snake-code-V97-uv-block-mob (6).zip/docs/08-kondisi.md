# Kondisi (if / elif / else)
`if` / `elif` / `else` boleh ditulis biasa. Bila dibungkus blok `[ ... ]` (opsional), tiap blok berdiri sendiri: `else` tidak bisa menyambung ke `if` di blok lain, dan `animation:cancel` hanya berlaku untuk animasi di blok yang sama. Untuk hal lain, buka blok `[ ]` baru. Blok tidak boleh bersarang dan tidak boleh berisi deklarasi `{...`.
```
[
    if(telor_mob_mod == right_click){
        spawn:monster
    }
]

[
    if(awmp == on){
        effect:night_vision infinite
    }else{
        effect:night_vision off
    }
]

[
    if(big_zombie == move){
        animation-true-start://:2610160006
    }
    else(jumpht === move){
        animation:cancel
    }
]

[
    if(peluru == null in inventory){
        no shoot
    }else{
        yes shoot
        peluru - 1
    }
]
```
- `===` = OR (menggantikan `##`; kode lama yang memakai `##` ditolak dengan pesan galat). Contoh: `if(item == on === item == right_click)`. Kondisi: `item on` (dipegang), `item right_click`, `mob move`, `move`, `jumpht`, `item == null in inventory`.
- Perintah: `spawn:mob` (muncul searah pandangan, 3 blok), `effect:nama infinite|off|Ns`, `start-animation://:ID`, `animation-true-start://:ID`, `animation:cancel`.
- Efek (`effect:`): efek yang diberikan Hydrogen X ditandai tag pemain `hx_fx_<nomor blok>_<efek>`. `effect:nama off` hanya mematikan efek yang diberikan Hydrogen X sendiri; efek dari ramuan, command, atau add-on lain tidak ikut terhapus dan tidak ditimpa (efek yang sama dari sumber lain dibiarkan sampai habis, lalu Hydrogen X mengambil alih bila kondisinya masih terpenuhi). `off` tanpa pemberi efek di add-on yang sama diberi peringatan.

## Menyentuh blok (touch)
```
[
    if(user == touch.oak_planks){
        effect:night_vision infinite
    }else{
        effect:off
    }
]
```
- `user == touch.nama_blok` (atau `player`): benar saat pemain menyentuh blok itu. Nama blok memakai nama resmi Minecraft tanpa `minecraft:` (contoh `oak_planks`, `stone`, `gold_block`). Blok dari add-on lain ditulis dengan namespace, contoh `touch.mypack:crate`. Translator tidak punya daftar blok resmi, jadi nama yang salah tulis tidak ditolak, hanya tidak pernah benar.
- Yang dihitung menyentuh: blok yang diinjak (di bawah kaki), blok di posisi kaki atau kepala, dan blok yang tepat di samping badan. Dicek tiap 0,5 detik.
- `effect:off` tanpa nama mematikan semua efek yang diberikan blok `if` yang sama (hanya efek buatan Hydrogen X, bukan efek dari ramuan atau sumber lain). Untuk satu efek saja tetap `effect:nama off`.
- `touch.` hanya untuk `user` / `player`.

## State, klik, dan attack

- `user` dan `player` sama-sama berarti pemain. Kondisi wajib memakai `==` (`X == state`); tanpa `==` ditolak dengan galat. State: `right_click`, `left_click`, `on`, `sit` (pemain sedang menaiki mob), `jumpht`, `flaying`, `move`, `host`.
- `attack` (pembaruan): `if(pedang == attack){ attack_effect: poison }`. Saat pemain memukul sesuatu dengan item itu, yang dipukul terkena effect. `attack_effect: nama` memakai nama resmi effect Minecraft Bedrock (speed, slowness, poison, wither, weakness, blindness, regeneration, levitation, dan seterusnya); nama asal-asalan ditolak dengan galat beserta daftar nama resmi. Durasi bawaan 10 detik, atau tulis `attack_effect: poison 5s`. Tingkat effect: `attack_effect: poison 5s level 2` (level 1 = biasa, level 2 lebih kuat, sampai level 256); tanpa durasi pun boleh: `attack_effect: poison level 3`. Boleh lebih dari satu baris attack_effect dalam satu blok. `user == attack` berlaku untuk semua pukulan pemain. `attack_effect` hanya bekerja di dalam blok `attack`.
- `right_click` dan `left_click` berlaku untuk pemain, item (`item == right_click`), dan mob (`mob == right_click`). `sit`: pemain naik ke mob yang diklik. `stand`: pemain turun. Pada `if(user == right_click){sit}else{stand}`, klik kanan pada mob = duduk, klik kiri = berdiri.

```
[
    if(user == right_click){
        sit
    }else{
        stand
    }
]
[
    if(airplane == flaying){
        animation-true-start://:2610160008
    }
]
```
