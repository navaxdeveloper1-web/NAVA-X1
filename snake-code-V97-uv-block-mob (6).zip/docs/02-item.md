# Item ({item)

```
{item
    name_tag:pedang_api
    icon_item://:2610160007
    damage:+6
    hp_item:30 hp
    coldown:5s
    max-item:1
    crafting:1, oak_planks
    crafting:4, oak_planks
    menu_creative:on
}
```

## Properti

- Item: `icon_item://:ID` (ikon png), `damage:`, `coldown:5s`, `max-item:1..64`, `hp_item:30 hp`, `shoot_radius:`, `boom-radius:`, `+give:` (harus sama dengan name_tag).

- Model 3D item: `models://:ID` berisi `.geo.json` (dan `models://:ID` png untuk teksturnya) membuat attachable: model tampil saat item dipegang, ikon inventory tetap 2D. Bone akar model diikat ke slot tangan; posisi dan ukuran mengikuti model Anda. Item tanpa model tidak berubah.

- `crafting:posisi, bahan`: posisi 1-9 pada grid 3x3 (kiri-atas ke kanan-bawah), bahan memakai nama resmi Minecraft. Menjadi resep shaped di Behavior Pack. Posisi yang sama dua kali ditolak.
- `menu_creative:off`: item disembunyikan dari Creative Inventory dan resepnya tidak dibuat (diberi peringatan); item hanya lewat `/give`.
- `icon_item://:ID` (atau `icon://:ID`): gambar ikon inventory item. Mob tidak punya ikon inventory, jadi diabaikan dengan peringatan.

## Crafting dan ikon (tambahan)

**Crafting (perbaikan):** pola resep dipangkas ke kotak terkecil (tanpa baris/kolom kosong) karena Bedrock tidak memuat pola dengan baris kosong; resep tetap cocok di posisi mana pun pada grid. Bisa memakai banyak posisi sekaligus (`crafting:1, 2, 3, obsidian`), nama bahan tidak peka huruf besar dan boleh diawali `minecraft:` (pakai `_`, bukan spasi). Resep selalu terbuka (`AlwaysUnlocked`).

**Ikon item besar:** Minecraft membuat item di tangan menjadi 3D dengan menjulurkan setiap piksel ikon. Ikon png yang lebih besar dari 32x32 otomatis dikecilkan ke 32x32 (rasio terjaga, tepi tegas) saat build supaya tidak lag; translator memberi peringatan. Ikon 32x32 atau lebih kecil tidak diubah.

## Senjata dan durability

- Senjata (`shoot_radius`): klik kanan menembak sejauh radius, damage sesuai `damage`, memakai 1 item amunisi (item `peluru` atau yang disebut di `== null in inventory`).
- Durability: berkurang Damage / 2 (dibulatkan ke atas) tiap memukul mob atau menghancurkan blok.

## Efek saat memukul

- `attack` (pembaruan): `if(pedang == attack){ attack_effect: poison }`. Saat pemain memukul sesuatu dengan item itu, yang dipukul terkena effect. `attack_effect: nama` memakai nama resmi effect Minecraft Bedrock (speed, slowness, poison, wither, weakness, blindness, regeneration, levitation, dan seterusnya); nama asal-asalan ditolak dengan galat beserta daftar nama resmi. Durasi bawaan 10 detik, atau tulis `attack_effect: poison 5s`. Tingkat effect: `attack_effect: poison 5s level 2` (level 1 = biasa, level 2 lebih kuat, sampai level 256); tanpa durasi pun boleh: `attack_effect: poison level 3`. Boleh lebih dari satu baris attack_effect dalam satu blok. `user == attack` berlaku untuk semua pukulan pemain. `attack_effect` hanya bekerja di dalam blok `attack`.

## destroying: area hancur
Item yang menghancurkan blok bisa merusak banyak blok sekaligus:

```
{item
    name_tag:kapak
}

if(kapak == attack){
    destroying: 4x4
}
```

- `destroying: LebarxTinggi` (contoh `4x4`), boleh ditambah kedalaman: `destroying: 4x4x2`. Tiap sisi 1 sampai 16 dan total maksimal 256 blok per pukulan.
- Area mengikuti sisi blok yang dipukul: dipukul dari atas/bawah = bidang datar (lebar x panjang); dipukul dari samping = dinding (lebar x tinggi). Blok yang dipukul menjadi bagian tengah area (untuk ukuran genap, area bergeser satu blok).
- Kondisi yang diterima: `item == attack`, `item == destroy`, atau `item == left_click` dengan nama item yang dideklarasikan. Pernyataan lain di blok yang sama (misalnya `attack_effect:`) tetap jalan.
- Blok bedrock, barrier, air/cairan, command block, dan sejenisnya dilewati. Mode survival menjatuhkan item (seperti dihancurkan biasa); creative tidak menjatuhkan item.
- Hanya berlaku saat item itu dipegang. Durability dikurangi satu kali per pukulan.

Untuk item yang bisa diupgrade level demi level, lihat `03-item-class.md`.

## Makanan ({food)
```
{food
    name_tag:super_food
    saturation:+2
    icon_item://:2611210005
}
```
- `{food` adalah item khusus makanan. Cukup dideklarasikan; **tidak perlu `if` / `elif` / `else`**. Tahan klik kanan untuk makan, persis seperti makanan Minecraft.
- Animasi makan, suara, dan lama makan memakai bawaan Minecraft (1,6 detik, seperti apel). Item makanan tidak dipegang seperti alat dan bisa ditumpuk sampai 64 (ubah dengan `max-item:`).
- `saturation:+N` (1 sampai 20): jumlah poin lapar yang terisi. 1 poin = setengah paha ayam, jadi `+2` = satu paha. Tanpa `saturation:` dipakai `+2` dengan peringatan.
- Properti lain: `name_tag:` (wajib), `icon_item://:ID` (ikon, juga `icon`, `asset_item`, `asset`), `models://:ID` (model 3D di tangan), `max-item:`, `crafting:`, `menu_creative:`. Properti senjata/alat seperti `damage:` atau `class:` tidak dipakai di `{food`.
- Muncul di Creative bagian Items. Nama makanan bisa dipakai di `crafting:` item lain (`hx:super_food`), di `item_drop:` blok (`item_drop:super_food`), dan di kondisi `if` seperti item biasa.
