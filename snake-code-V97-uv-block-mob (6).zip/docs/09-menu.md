# Menu: jendela menu yang diatur if / else
```
{menu
display:invisible
name_tag:menu_pilihan
radius:25x25 px
background:red
button_place:x(6) y(7) "klik saya"
}

if(menu_pilihan == click_e === button_x(5)_Y(5)"menu"){
    display:blok
}else{
    display:invisible
}

if(klik saya == click){
    menu_pilihan: invisible
}
```
Menu tampil sebagai **jendela form bawaan Minecraft** (judul dan tombol berurutan). Yang berlaku:
- `name_tag:` wajib; judul jendela = nama itu (menu_pilihan menjadi "Menu Pilihan").
- `display:blok` (tampil) atau `display:invisible` (sembunyi), seperti display block / none pada div. Di `{menu` menjadi keadaan awal: `blok` membuka menu otomatis saat pemain masuk dunia. Di dalam `if`, `display:blok` membuka menu, `display:invisible` menandainya tertutup, dan `nama_menu: blok` / `nama_menu: invisible` mengatur menu tertentu. Form yang sedang terbuka tidak bisa ditutup paksa oleh skrip; ia tertutup saat pemain memilih tombol atau menutupnya.
- `button_place:x(6) y(7) "label"`: satu tombol per baris. Koordinat dipakai untuk **urutan** tombol (y lebih kecil dulu, lalu x). Posisi piksel sebenarnya, `radius`, dan `background` tidak bisa dipakai di form bawaan: `radius` diabaikan (dengan peringatan), `background` dipakai sebagai warna ikon tombol peluncur. Maksimal 20 tombol; label tidak boleh sama.
- `menu == click_e`: menu dibuka lewat **item peluncur** bernama `hx:nama_menu_menu`, yang otomatis diberikan ke pemain (masuk dunia dan bila hilang) dan dibuka dengan klik kanan. Tombol E pada keyboard tidak bisa dideteksi Minecraft, jadi item ini dipakai di PC dan HP. `button_x(5)_Y(5)"menu"` = tombol peluncur itu; teks "menu" menjadi nama item.
- `else` pada if menu berjalan saat menu **ditutup** (tombol batal / ESC), jadi `display:invisible` di else mencatat menu tertutup.
- `label == click`: berjalan saat pemain memilih tombol berlabel itu. Label ditulis persis seperti di `button_place` (boleh spasi karena itu teks tombol).
- Butuh modul `@minecraft/server-ui` (otomatis ditambah ke manifest).
