# Pemain, Custom, dan bed (sistem Bedwars)
```
{user
    user_1:user
    user_2:user
    user_3:host_user
}

{Custom
    red_bed:user_1
    point = 0
}

{custom
    blue_bed:user_2
    point = 0
}

{custom
    white_bed:user_3
    point = 0
}

if(red_bed == destroy ){
    user_1.mode:spectator
}elif(blue_bed == destroy){
    user_2.mode:spectator
}elif(white_bed == destroy){
    user_3.mode:spectator
}

if(user_N == destroying bed){
    poin + 1
}
```
- `{user` mendaftarkan pemain: `user_1:user` pemain biasa, `user_3:host_user` host yang ikut bermain. Nama pemain harus `user_1`, `user_2`, dan seterusnya. Hanya boleh satu `host_user`.
- `{Custom` dan `{custom` sama-sama diterima (penulisan asli dipertahankan). Isinya satu pasangan `objek_resmi:user_N`, misalnya `red_bed:user_1` (bed milik user 1), dan boleh satu `point = angka` (nilai awal point pemilik). `point = ` hanya berlaku di `{Custom`. Nama objek dipetakan ke blok resmi `minecraft:nama`.
- `objek == destroy`: terpenuhi saat blok itu dihancurkan. `user_1.mode:spectator` mengubah mode pemain pada slot itu (survival, creative, adventure, spectator).
- `user_N == destroying bed`: `user_N` mewakili semua pemain terdaftar, yaitu pemain yang melakukan aksi (bukan pemilik bed). `poin + 1` menambah 1 point ke pemain itu, apa pun warna dan pemilik bed, termasuk bed miliknya sendiri.
- Cara translator mengerjakannya: slot pemain dibagi menurut urutan masuk dunia, kecuali slot `host_user` yang diberikan ke pemain operator (host) bila ada. Slot tersimpan di dunia. Point disimpan di scoreboard `hx_point` (lihat dengan `/scoreboard players list`). `destroying bed` berlaku untuk setiap blok bed.
- Belum dikerjakan: hak pengelolaan mod oleh host (belum ada perintahnya di spesifikasi), bed yang rusak karena ledakan atau sebab lain selain dihancurkan pemain, dan tampilan papan point. Hasil belum diuji di dalam Minecraft.

## Nama pemain dan mode host

```
{costum
    name_user:fadhil
}
[
    if(fadhil == host){
        mode:creative
    }
]
```

- `{costum name_user:nama` + `if(nama == host){mode:...}`: pemain bernama itu (huruf besar/kecil tidak dibedakan) mendapat mode `survival`, `creative`, `adventure`, atau `spectator` saat masuk dunia.
