# Perbedaan dari spesifikasi (karena batas Minecraft Bedrock)
- Identitas item dan mob memakai awalan `hx:` (Bedrock mewajibkan namespace), jadi `/give @a hx:sword_flash 1`, bukan `/give @a sword_flash 1`.
- `boom-radiusY` dibaca tetapi belum dipakai (ledakan Minecraft bulat). `capacity` dan `key` selain klik kanan belum dipakai. Semuanya muncul sebagai peringatan, bukan galat.
- Contoh di dokumentasi V2.2 bagian 6 dan 9 memberi koma hanya pada properti terakhir; itu melanggar aturan koma, jadi ditolak. Hapus koma itu atau beri koma ke semua properti.
- Komentar: baris yang diawali `//` lalu spasi. ID aset `//:2610160001` bukan komentar.
- Hasil belum diuji di dalam Minecraft; format file mengikuti Bedrock 1.20.80. Bila Minecraft menolak sebuah file, laporkan pesan galatnya.
