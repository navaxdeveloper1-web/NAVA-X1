# Animasi pemain (user / player)
Animasi juga bisa dijalankan pada pemain, ditulis di blok `if` yang kondisinya `user` atau `player`:
```
[
    if(user == right_click){
        start-animation://:2611170003
    }
]
[
    if(user == sit){
        animation-true-start://:2611170003
    }else{
        animation:cancel
    }
]
```
- Kondisi yang didukung untuk pemain: `right_click`, `left_click`, dan `sit`. Kondisi lain (misalnya `jumpht`, `move`) belum bisa memicu animasi pemain dan diberi peringatan.
- `start-animation` memutar sekali (tiap klik memutar ulang). `animation-true-start` berulang sampai `animation:cancel` dijalankan.
- Cara kerjanya: animasi disalin ke Resource Pack (loop diatur otomatis), lalu skrip memanggil `/playanimation` pada satu controller bersama, jadi animasi baru menggantikan yang lama dan `animation:cancel` memutar animasi kosong. Add-on tidak menimpa file pemain bawaan Minecraft.
- Nama bone di file animasi harus cocok dengan model pemain (`head`, `body`, `rightArm`, `leftArm`, `rightLeg`, `leftLeg`). Belum diuji di dalam Minecraft; bila tidak jalan, laporkan perilakunya.

`animation:cancel` tetap menghentikan animasi. Sintaks lama (`asset:`, `asset_item:`, `animation:` dan `start_animation:`) masih diterima supaya kode lama tidak rusak, tetapi `start_animation:` diberi peringatan agar diganti. `{asset` juga menerima keempat bagian itu untuk memberi nama pada sebuah kode, lalu nama itu dipakai sebagai pengganti `//:ID`.
Aset yang tidak ada diganti kotak dan warna polos bawaan supaya add-on tetap jadi dan bisa dicoba.

## Animasi mob
Animasi mob ditulis di blok `if` memakai `start-animation://:ID` (sekali) atau `animation-true-start://:ID` (berulang); detailnya ada di `06-aset.md` bagian aset dan di `08-kondisi.md`.
