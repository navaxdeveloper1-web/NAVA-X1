# Setup add-on ({setup)

```
{setup
    version_minecraft_support:26.10 and 26.50
    version_mod:1.0.0
    description:Airplane Mod
    icon_mod://:2610160009
}
```

- `{setup`: `version_mod` menjadi versi pack, `description` menjadi deskripsi pack, `icon_mod` menjadi pack_icon.png, `version_minecraft_support:A` atau `A and B` menjadi versi minimum (`min_engine_version`). Penulisan harus versi resmi Bedrock: versi baru `26.0`, `26.1`, `26.10`, `26.50`, `26.63` dst. (daftar yang diketahui translator: 26.0, 26.1, 26.3, 26.10, 26.20, 26.30, 26.40, 26.43, 26.50, 26.51, 26.52, 26.60, 26.62, 26.63) atau versi lama `1.20.80` sampai `1.21.x`. Penulisan seperti `1.26` atau `1.50` ditolak. Versi 26.x yang tidak ada di daftar tetap diterima dengan peringatan. Bedrock tidak punya batas maksimum, jadi B hanya dicatat dengan peringatan. Versi minimum di bawah 1.20.80 dinaikkan ke 1.20.80. Untuk 26.N, `min_engine_version` ditulis `[1, 26, N]`. Hanya satu `{setup` per file.
