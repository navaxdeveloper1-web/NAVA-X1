# Command chat ({command)

```
{command
    command:/start
    command:/skor
}

if(word == /start){
    out#"Selamat datang!";
}

if(word == /skor){
    out#"skor:";
    out#"Andi: 56";
}
```

Hasil: saat pemain mengetik `skor` di chat, muncul di chat:
```
skor:
Andi: 56
```

- `{command` mendaftarkan perintah, satu baris `command:/nama` per perintah. Nama diawali `/`, huruf kecil, angka, atau `_`. Perintah yang sama dua kali ditolak.
- `word == /nama` (di `if` / `elif` / `else`) berjalan saat pemain memanggil perintah itu. `word` adalah kata yang diketik pemain. Perintah yang tidak punya blok `if` diberi peringatan karena tidak melakukan apa-apa.
- `out#"teks";` menampilkan teks sebagai pesan chat ke pemain yang mengetik. Teks wajib diapit tanda kutip ganda; `;` di akhir boleh. Satu baris per pesan. `out#` juga bisa dipakai di blok `if` lain (klik, attack, dan seterusnya).
- Cara memanggil: ketik `skor` atau `!skor` di chat (pesannya tidak ikut tampil ke pemain lain). Di versi Minecraft yang punya custom command, perintah juga didaftarkan sebagai `/hx:skor`.
- Batasan: Minecraft tidak membolehkan skrip membuat perintah garis miring polos seperti `/skor`; custom command wajib memakai namespace (`/hx:skor`). Karena itu `/skor` yang diketik langsung akan dijawab "unknown command" oleh Minecraft, bukan oleh Hydrogen X.
- Belum diuji di dalam Minecraft. Fitur ini bergantung pada event chat (`world.beforeEvents.chatSend`) atau custom command yang ada di versi Anda; bila keduanya tidak ada, perintah tidak merespons.
