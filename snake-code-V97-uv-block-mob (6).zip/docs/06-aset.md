# Aset (kode //:)
Unggah lewat File > Upload Asset, lalu pakai kodenya di salah satu bagian aset (lihat 3b). Saat build, translator mengunduh aset dan mengenali jenisnya dari isinya:
- png: tekstur mob atau ikon item
- `.geo.json`: model mob (unggah dengan nama berakhiran `.geo.json`)
- `.animation.json`: animasi mob
- glb, obj, fbx, dll belum bisa dikonversi menjadi model Bedrock (dilewati dengan peringatan).

## Bagian aset: models, icon_item, start-animation, animation-true-start
`asset:` kini dipecah menurut fungsinya:
- `models://:ID`: model 3D. Pada item = model yang tampil saat dipegang (attachable); pada mob = model dan tekstur mob. Isinya `.geo.json`, dan png untuk teksturnya (tulis dua baris `models:`).
- `icon_item://:ID`: ikon inventory item (png). Hanya untuk item; di mob diabaikan dengan peringatan.
- `start-animation://:ID`: animasi yang diputar sekali. Setelah selesai tidak diulang sampai kondisinya padam dan menyala lagi.
- `animation-true-start://:ID`: animasi yang diputar berulang (loop) selama kondisinya benar.
Keduanya hanya ditulis di dalam blok `if` / `elif` / `else`, supaya animasi jalan atas kehendak developer. Bila ditulis langsung di `{mob`, animasi akan jalan sendiri tanpa kondisi, jadi baris itu diabaikan dengan peringatan.
```
{item
    name_tag:airplane_egg
    models://:2611170001
    models://:2611170004
    icon_item://:2611170006
}
{mob_netral
    name_tag:airplane
    models://:2611170001
}
[
    if(airplane == flaying){
        animation-true-start://:2611170003
    }else{
        animation:cancel
    }
]
```

**Format gambar:** aset gambar boleh png, apng, jpg/jpeg/jfif, gif, webp, bmp, avif, ico, svg, dan tiff. Selain png yang biasa, semuanya diubah otomatis ke png saat build (butuh browser); png yang tidak biasa (interlaced) juga dinormalkan. jpg/gif tidak punya transparansi penuh, jadi pakai png untuk latar transparan.
