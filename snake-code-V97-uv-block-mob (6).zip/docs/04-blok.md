# Blok custom ({block / {item_block)
```
{item_block
    name_tag:diamond_merah
    icon_item://:2611190010
    hardness:3
    light:7
    crafting:1, 2, 3, iron_ingot
    crafting:5, obsidian
}

if(diamond_merah == right_click){
    place_block:diamond_merah
}
```
- `{block` (atau `{item_block`, artinya sama) membuat **blok custom** `hx:nama`. Wajib `name_tag:`. Item blok dibuat Minecraft otomatis dan sudah bisa dipasang dengan klik kanan di dunia tanpa kode tambahan.
- Tekstur: gambar apa pun lewat `icon_item://:ID` (juga `icon`, `asset_item`, `asset`, `models`), dipakai di semua sisi. Tekstur dibuat persegi dan maksimal 64x64 agar ringan. Tanpa gambar dipakai warna polos.
- `hardness:` lama menghancurkan dengan tangan (detik, bawaan 2). `light:` cahaya 0 sampai 15. `menu_creative:off` menyembunyikan dari menu kreatif. `crafting:` sama seperti item.
- `place_block:nama` (di dalam `if`): memasang blok itu di sisi blok yang sedang dilihat pemain, hanya di tempat kosong. Bisa dipakai oleh item lain (misalnya `if(tongkat == right_click){ place_block:diamond_merah }`). Bila yang dipegang adalah item blok itu sendiri, jumlahnya berkurang satu di survival.
- Spasi tidak diterima: tulis `{item_block`, `right_click`, `left_click`, dan nama bahan seperti `iron_ingot` dengan garis bawah `_`. Penulisan dengan spasi ditolak dengan pesan galat.
- Nama blok bisa dipakai sebagai item pada kondisi (`diamond_merah == right_click`) dan pada `crafting` item lain lewat nama lengkapnya (`hx:diamond_merah`).

## Drop barang saat blok dihancurkan (item_drop)
```
{block
    name_tag:diamond_merah
    models://:2611210001
}

{item
    name_tag:diamond_merah_ingot
    icon_item://:2611210002
}

if(diamond_merah == destroy){
    item_drop:diamond_merah_ingot
}
```
- `item_drop:nama` (di dalam `if(nama_blok == destroy)`) menentukan barang yang jatuh saat blok custom itu dihancurkan. Dibuat sebagai loot table di Behavior Pack (`loot_tables/blocks/nama.json`), jadi berlaku saat mode survival; mode creative tidak menjatuhkan apa pun, sama seperti Minecraft biasa.
- Jumlah: `item_drop:nama` (1 buah), `item_drop:nama 3` (3 buah), atau `item_drop:nama 2-4` (acak 2 sampai 4). Batas 1 sampai 64.
- Boleh banyak baris `item_drop:`; tiap baris pasti jatuh. Item bisa buatan sendiri (`{item`, tulis `name_tag`-nya) atau item resmi Minecraft (`item_drop:iron_ingot`, pakai `_`, tanpa spasi). Nama yang tidak dideklarasikan dianggap item resmi; bila mirip nama item Anda, muncul peringatan "Did you mean".
- Bila ada `item_drop:`, blok **tidak** lagi menjatuhkan dirinya sendiri. Ingin tetap menjatuhkan blok itu juga: tambah `item_drop:diamond_merah`.
- Tanpa `item_drop:`, blok menjatuhkan dirinya sendiri seperti biasa.
- Nama di `if(... == destroy)` harus blok yang dideklarasikan dengan `{block`. Salah ketik nama (misalnya `dimond_merah`) atau kondisi selain `destroy` ditolak dengan galat beserta daftar blok yang ada.

## Mengganti tekstur blok Minecraft bawaan
```
{obsidian
    models://:2611210002
}
```
- Tulis nama blok bawaan Minecraft sebagai `{nama`, lalu `models://:ID` berisi gambar png milik Anda (juga `icon_item`, `asset`, `asset_item`, `icon`). Hydrogen X menimpa berkas tekstur blok itu di Resource Pack, jadi blok `obsidian` asli di dunia tampil dengan gambar Anda. Tidak perlu `name_tag`.
- Satu gambar dipakai untuk semua sisi blok. Gambar dibuat persegi dan maksimal 64x64.
- Tanpa gambar yang bisa dipakai, hanya muncul peringatan dan tekstur bawaan dipertahankan. Satu blok hanya boleh dideklarasikan sekali.
- Blok yang didukung: obsidian, crying_obsidian, bedrock, stone, cobblestone, stone_bricks, bricks, dirt, sand, gravel, clay, sponge, snow, ice, glass, netherrack, end_stone, soul_sand, glowstone, sea_lantern, diamond_block, gold_block, iron_block, emerald_block, lapis_block, redstone_block, coal_block, netherite_block, copper_block, amethyst_block, coal_ore, iron_ore, gold_ore, diamond_ore, emerald_ore, lapis_ore, redstone_ore, oak_planks, spruce_planks, birch_planks, jungle_planks, acacia_planks, dark_oak_planks, tnt. Nama lain ditolak dengan daftar ini.
- Belum diuji di dalam Minecraft; nama berkas mengikuti Resource Pack Bedrock. Pastikan Resource Pack add-on aktif di dunia.

## Bom nuclier: blok yang dinyalakan lalu meledak
```
{block
    name_tag:nuclier
    models://:2611210003
}

if(flint_and_steel == nuclier){
    wait:6 second
    boom:on
    radius:3x3x3
}
```
- `if(item == blok)` terpenuhi saat pemain memakai item itu pada blok custom (klik kanan). Nama item memakai **nama resmi Minecraft Bedrock bahasa Inggris**, tanpa spasi: korek = `flint_and_steel` (Flint and Steel). Nama Indonesia seperti `korek` ditolak dengan galat. Item buatan sendiri (`{item`) juga boleh.
- Saat dinyalakan, blok berubah menjadi bom (entitas `hx:nuclier_primed`, memakai tekstur blok itu) yang **berkedip** putih dan normal bergantian tiap 0,25 detik seperti TNT bawaan Minecraft, dengan suara sumbu menyala. Api bawaan korek tidak muncul. Di survival korek berkurang 1 durability, di creative tidak.
- `wait:6 second` = lama hitung mundur, 0 sampai 600 detik (boleh pecahan: `wait:1.5 second`). Tanpa `wait` dipakai 4 detik seperti TNT.
- `boom:on` = meledak setelah hitung mundur. `boom:off` atau tanpa baris `boom`: bom hanya berkedip lalu hilang (diberi peringatan).
- `radius:` = ukuran area yang dihancurkan, berpusat di bom. `radius:3x3x3` = lebar (X) x tinggi x lebar (Z) = kubus 3 blok. `radius:5000x5000` = X x Z (tinggi = angka terkecil, terpotong oleh tinggi dunia). `radius:10` = kubus 10 x 10 x 10. Tiap sisi 1 sampai 5000. Tanpa `radius` dipakai 3x3x3.
- Cara menghancurkan: area dibagi per chunk, dimulai dari pusat, dikerjakan bertahap beberapa tick supaya game tidak macet. Minecraft hanya mengizinkan chunk yang sedang termuat (dekat pemain) diubah: chunk yang tidak termuat dilewati. Untuk area besar muncul ringkasan `Nuclier: N of M chunks cleared`. Untuk menghancurkan area 5000 x 5000 penuh, semua chunk itu harus termuat.
- Lapisan bedrock paling bawah Overworld dan lantai/atap bedrock Nether tidak ikut hancur. Blok yang hancur menjatuhkan item hanya bila total area 1000 blok atau kurang; area lebih besar langsung dihapus tanpa drop agar game tidak macet.
- Efek ledakan (suara, partikel, damage ke sekitar) berukuran sekitar setengah sisi terbesar, minimal 3 dan maksimal 12, tanpa api. Penghancuran blok memakai ukuran `radius:` persis, bukan bola ledakan.
- Beberapa blok bom boleh dibuat dengan beberapa `if(... == blok)`; satu `if` bisa memakai `===` untuk beberapa item. Nama `nama_primed` dicadangkan untuk entitas bom dan tidak boleh dideklarasikan. Nama blok yang belum dideklarasikan dengan `{block` hanya memberi peringatan dan `if` itu dilewati.
- Belum diuji di dalam Minecraft; disimulasikan di tes translator. Pastikan Behavior Pack dan Resource Pack add-on aktif, dan Experiments tidak diperlukan.

## Muncul sendiri di dunia (random_block)
```
{Block
    name_tag:ore
    random_block:-15
}
```
- `random_block:` membuat blok muncul sendiri di dunia Overworld sebagai gumpalan ore (8 blok per gumpalan), menggantikan batu, deepslate, tanah, pasir, kerikil, dan blok alami sejenis.
- Blok bisa ditemukan di **kedalaman apa pun**, dari dasar dunia (Y -64) sampai batas atas dunia (Y 320). Angkanya adalah kedalaman Y tempat blok paling sering muncul (puncaknya, sekitar 16 blok di atas dan bawahnya); `random_block:-15` paling banyak di Y -15, `random_block:64` di permukaan.
- Angka boleh bilangan bulat apa pun, negatif atau positif. Di luar -64 sampai 320 dipindah ke batas terdekat dengan peringatan.
- `random_block:any` (atau `all`): rata di semua kedalaman, tanpa puncak.
- Dibuat sebagai `features/` dan `feature_rules/` di Behavior Pack. Hanya berlaku untuk chunk baru yang dibuat setelah add-on dipasang; chunk yang sudah dijelajahi tidak berubah.
- Huruf pertama baris yang dibesarkan otomatis oleh keyboard (`{Block`, `Name_tag:`, `Random_block:`, `If(`) diterima sama seperti huruf kecil.
- Belum diuji di dalam Minecraft; disimulasikan di tes translator.

## UV mapping (satu gambar dilipat jadi kubus)
```
{Block
    name_tag:ore
    models://:2611210009
}
```
- Cukup unggah **satu png tata letak UV**; translator melipatnya jadi kubus 3D, tanpa model `.geo.json`. Dikenali dari bentuk gambar:
  - **Lebar 2x tinggi** (mis. 64x32): UV kotak Minecraft/Blockbench. Baris atas: kosong, **atas**, **bawah**, kosong. Baris bawah: **timur, utara (depan), barat, selatan**.
  - **Lebar 4 : tinggi 3** (mis. 64x48): salib mendatar. Baris atas: atas di atas utara. Baris tengah: timur, utara, barat, selatan. Baris bawah: bawah di bawah utara.
  - Gambar **persegi** (1:1) = satu gambar di semua sisi seperti biasa.
- Lebar harus kelipatan 4. Gambar UV tidak diperkecil atau diubah jadi persegi; disarankan lebar 256 atau kurang (lebih dari 512 diberi peringatan).
- `uv_mapping:off` memaksa gambar dipakai utuh di semua sisi walau bentuknya mirip UV.
- Bom `nuclier` memakai UV yang sama saat menyala.
- Belum diuji di dalam Minecraft; arah gambar sisi atas dan bawah mengikuti aturan UV kotak Blockbench dan bisa saja perlu dibalik. Bila terbalik, beri tahu agar disesuaikan.

## Menyentuh blok
Kondisi `user == touch.nama_blok` (pemain menyentuh blok) ada di `08-kondisi.md`.
