# Class item dan Buku Sihir
```
{item
    name_tag:pedang_naga
    class:sword
    max_level:5
}
{item
    name_tag:kapak_sakti
    class:pick_axe
    damage:+4
}
{item
    name_tag:baju_besi
    class:armor
    armor_slot:chestplate
}
```
- `class:` menentukan jenis item: `sword`, `axe`, `pick_axe`, `shovel`, `hoe`, `armor`. Armor memakai `armor_slot:` `helmet`, `chestplate` (bawaan), `leggings`, atau `boots` (boleh juga ditulis langsung `class:helmet` dan seterusnya).
- Status dasar (level 1): sword damage 5, axe 6, pick_axe 3, shovel 4, hoe 1, durability 250; armor proteksi helmet 2, chestplate 6, leggings 5, boots 2. `damage:` dan `hp_item:` menimpa nilai dasar. Pick_axe, axe, shovel, dan hoe otomatis bisa menggali (kecepatan dasar 6); semua class item bisa di-enchant.
- `max_level:` (1 sampai 10, bawaan 5): level tertinggi. Tiap level naik: damage +20%, durability +25%, kecepatan gali +25%, proteksi armor +25%. Level 2 ke atas bercahaya (glint) dan tingkat bahan gali naik (diamond, lalu netherite pada level 4).
- Tiap level adalah item sendiri: `hx:pedang_naga` (Lv.1), `hx:pedang_naga_lv2` ... `hx:pedang_naga_lv5`. Hanya Lv.1 muncul di Creative dan punya resep `crafting:`; level lain lewat upgrade atau `/give`. Nama `nama_lvN` dicadangkan dan ditolak bila dipakai deklarasi lain.
- **Buku Sihir** (`hx:buku_sihir`) dibuat otomatis bila ada item class. Resep: buku + lapis lazuli + diamond (susunan bebas), juga ada di Creative. Klik kanan sambil memegang Buku Sihir: muncul daftar item class di inventory dan yang sedang dipakai (armor, tangan kiri); pilih satu untuk naik 1 level memakai 1 buku (mode creative tidak memakai buku). Sisa durability (rasio), nama, dan enchant ikut terbawa. Item yang sudah level maksimal tidak ditampilkan.
- Ingin Buku Sihir sendiri (ikon, resep)? Tulis `{item name_tag:buku_sihir` dengan properti Anda; item itu dipakai sebagai buku upgrade.
- Kondisi `if(pedang_naga == attack)` dan sejenisnya berlaku untuk semua level.
- Armor melindungi dan bisa rusak, tetapi tampilan di badan belum digambar (butuh model armor). Hasil belum diuji di dalam Minecraft.
