# Variabel (int, double, auto)

```
int point = 67
double speed = 1.5
auto nama = "Andi"

{command
    command:/skor
}

if(word == /skor){
    out#"point: " + point;
    point += 3
    point -= 1
    speed *= 2
    nama += "!"
    out#nama + " punya " + point + " poin";
}
```

- Tipe: `int` (bilangan bulat, maksimal 14 digit), `double` (bilangan desimal, maksimal 15 digit), `auto` (mengikuti nilainya: bulat, desimal, atau teks dalam tanda kutip ganda). Nilai di atas batas dipotong ke batas; `int` membuang bagian desimal (7 / 2 = 3); `double` dibulatkan ke 15 digit (0.1 + 0.2 = 0.3).
- Nilai awal wajib. `int` tidak boleh diberi desimal atau teks, dan `double` tidak boleh diberi teks (galat saat build). Teks hanya untuk `auto`.
- Variabel global: ditulis di luar blok `if`. Nilainya tersimpan di dunia (tetap ada setelah dunia ditutup) dan dibagi semua pemain. Nilai awal dipakai sekali; bila nilai awal diubah di kode lalu add-on dibuild ulang, variabel itu dimulai lagi dari nilai awal yang baru.
- Variabel lokal: dideklarasikan di dalam blok `if`/`elif`/`else`. Hanya hidup selama blok itu berjalan dan dibuat ulang setiap kali blok berjalan. Nama tidak boleh sama dengan variabel global atau variabel lain di blok itu.
- Mengubah nilai: `=`, `+=`, `-=`, `*=`, `/=`, `nama++`, `nama--`. Nilai di kanan bisa angka, teks, variabel lain, atau hitungan dengan `+ - * /` dan tanda kurung, misalnya `point = (point + bonus) * 2`. `-=`, `*=`, `/=` hanya untuk angka; teks hanya bisa disambung dengan `+` atau `+=`.
- `out#`: gabungkan teks, angka, dan variabel dengan `+`, misalnya `out#"point: " + point;`. Di `out#`, `+` selalu menyambung teks (bukan menjumlah). Nama yang bukan variabel harus diberi tanda kutip.
- Nama variabel: huruf, angka, `_`, tidak diawali angka. Kata tercadang (int, double, auto, out, if, elif, else, user, word, sit, stand, poin, effect, mode, control, spawn, display, place_block, item_drop, destroying, animation) tidak boleh dipakai.
- Belum diuji di dalam Minecraft; diuji lewat tes dengan Minecraft tiruan. Penyimpanan memakai dynamic property dunia `hx_vars`.
