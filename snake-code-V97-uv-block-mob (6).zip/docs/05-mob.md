# Mob ({mob, {mob_hostile, {mob_netral, {mob_adaptive)

```
{mob_hostile
    name_tag:big_zombie
    models://:2610160005
    animation-true-start://:2610160006
    hp:60 hp
    damage:+6
}
```

- Mob: `hp:`, `damage:` (+N total, ++N tambah ke dasar 1), `models://:ID` (model .geo.json dan tekstur png), animasi lewat blok if (`start-animation://:ID` sekali, `animation-true-start://:ID` berulang).

## Mob terbang dan kursi

```
{mob_netral
    name_tag:airplane
    fly:on
    move:off
    lead:none
    seat_count:1
    seat_position:0, 1.2, 0
}
```

- `fly:on`: mob terbang tanpa gravitasi. `move:off`: tidak bergerak sendiri (tanpa jalan-jalan acak). `lead:none`: tidak bisa diikat Lead (tanpa ini mob bisa diikat).
- Mob dengan kursi bisa dinaiki. Mob terbang berkursi dikendalikan WASD dan arah pandang (kendali bawaan Bedrock), jadi `control:...` hanya dicatat.

- `flaying` pada mob = mob sedang di udara (`query.is_on_ground`). `user` dan `player` adalah pemain yang sama. Bila pemain melompat (`jumpht`) atau bergerak (`move`) dan blok animasinya berisi `animation:cancel`, animasi mob berhenti langsung di tengah jalan, dan jalan lagi setelah pemain berhenti. Berlaku untuk mob beranimasi dalam 16 blok dari pemain. `jumpht` atau `move` tanpa nama (contoh `else(jumpht ## move)`) juga berarti pemain. Dengan `mob move` atau `mob == flaying` di blok animasi, kondisi itu dibaca dari mob itu sendiri.

## Mob dari gambar png saja
Mob yang hanya diberi gambar png (tanpa `.geo.json`) menjadi **model bulat 3D**: siluet gambar (bagian tidak transparan) diputar mengelilingi sumbu tegak, gambar menempel di semua sisi. Pakai png berlatar transparan, satu objek tampak depan. Tinggi maksimal 4 blok. `shape:round` (bawaan) = bulat 3D; `shape:flat` = papan kardus datar 2D. Model dibuat ringan agar FPS tidak turun: bagian gambar yang lebarnya sama digabung jadi satu irisan (maksimal 16 irisan), tiap irisan berupa cincin 8 papan yang hanya menggambar sisi depan, dan materialnya `entity_alphatest` (cutout).

**Skin Minecraft:** png berukuran skin (64x64, 64x32, atau kelipatannya seperti 128x128 dan 512x512) otomatis dibentuk menjadi **karakter manusia**: kepala, badan, dua tangan, dua kaki, dan lapisan luar (topi, jaket, lengan baju, celana) bila skin punya bagian transparan. Minecraft membentuk tubuh dari tata letak skin standar, tanpa `.geo.json`. Lengan ramping (Alex) terdeteksi otomatis atau tulis `shape:slim`; `shape:humanoid` memaksa lengan biasa (Steve). Skin 64x32 lama didukung. Mob humanoid mendapat animasi jalan bawaan (tangan dan kaki berayun, kepala mengikuti arah pandang) selama pengguna tidak memasang animasi sendiri. Tulis `shape:round` atau `shape:flat` bila png berukuran skin ingin dipakai sebagai gambar objek. JPG diubah otomatis ke png di editor, tetapi JPG tidak punya transparansi sehingga lapisan luar dilewati; simpan skin sebagai png untuk hasil terbaik.

## UV mapping untuk mob
```
{mob
    name_tag:kotak
    models://:2611210009
}
```
- Mob yang hanya diberi png UV (tanpa `.geo.json`) dilipat jadi **kubus 3D satu blok** (16x16x16). Bentuk gambar dibaca sama seperti blok di `04-blok.md`: salib 4:3 (mis. 64x48) otomatis jadi kubus.
- UV kotak 2:1 (mis. 64x32) sama dengan ukuran skin Minecraft lama, jadi tanpa petunjuk dianggap skin manusia. Tulis `shape:cube` agar dibaca sebagai UV kubus.
- Mob dengan `.geo.json` tidak berubah: UV mengikuti modelnya sendiri.
