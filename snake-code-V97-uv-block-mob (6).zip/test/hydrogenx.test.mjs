import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdtempSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join } from "node:path";
import vm from "node:vm";

const ctx = { TextEncoder, TextDecoder, Uint8Array, Uint32Array, DataView, ArrayBuffer, Math, Date, JSON, Object, Array, String, Map, Set, Error, Promise };
vm.createContext(ctx);
const page = readFileSync(new URL("../index.html", import.meta.url), "utf8");
const src = /<script id="hydrogenx">([\s\S]*?)<\/script>/.exec(page);
assert.ok(src, "translator Hydrogen X harus tertanam di index.html");
vm.runInContext(src[1], ctx);
const { HydrogenX: HX } = ctx;
const dec = (f) => new TextDecoder().decode(f.data);
const find = (r, p) => r.files.find((f) => f.path === p);
const J = (r, p) => JSON.parse(dec(find(r, p)));

const anim = new TextEncoder().encode(JSON.stringify({ format_version: "1.8.0", animations: { "animation.zombie.walk": { loop: true } } }));
const geo = new TextEncoder().encode(JSON.stringify({ format_version: "1.12.0", "minecraft:geometry": [{ description: { identifier: "geometry.zombie" }, bones: [] }] }));
const png = HX.pngSolid(16, 16, [200, 50, 50]);
const fetchAsset = async (id) => ({ "2610160001": png, "2610160002": geo, "2610160003": anim }[id] || null);

const SRC = `{mob_hostile
    name_tag:big_zombie
    asset://:2610160001
    asset://:2610160002
    hp:60 hp
    damage:+6
}
{item
    asset_item://:2610160001
    name_tag:awmp
    damage:+10
    shoot_radius:10 blok
    max-item:1
}
{item
    name_tag:peluru
    max-item:40
}
{item
    name_tag:pedang
    damage:+6
    hp_item:30 hp
    coldown:5s
}
{item
    name_tag:telor
}
{mob_hostile
    name_tag:monster
    damage:+5
}
if(peluru == null in inventory){
    no shoot
}else{
    yes shoot
    peluru - 1
}
if(big_zombie == move){
    start_animation://:2610160003
}
else(jumpht === move){
    animation:cancel
}
if(awmp == on){
    effect:night_vision infinite
}else{
    effect:night_vision off
}
if(telor == right_click){
    spawn:monster
}
`;

test("menghasilkan struktur Add-on lengkap dan JSON valid", async () => {
  const r = await HX.translate(SRC, { name: "uji.hx", fetchAsset });
  for (const p of ["uji_BP/manifest.json", "uji_RP/manifest.json", "uji_BP/entities/big_zombie.json", "uji_RP/entity/big_zombie.entity.json", "uji_RP/models/entity/big_zombie.geo.json", "uji_RP/animations/big_zombie.animation.json", "uji_RP/animation_controllers/big_zombie.animation_controllers.json", "uji_BP/items/awmp.json", "uji_RP/textures/item_texture.json", "uji_BP/scripts/main.js"]) assert.ok(find(r, p), "hilang: " + p);
  for (const f of r.files) if (f.path.endsWith(".json")) JSON.parse(dec(f));
  const bp = J(r, "uji_BP/manifest.json"), rp = J(r, "uji_RP/manifest.json");
  assert.equal(bp.dependencies[0].uuid, rp.header.uuid);
  assert.ok(bp.modules.some((m) => m.type === "script"));
});

test("properti mob dan item mengikuti spesifikasi", async () => {
  const r = await HX.translate(SRC, { name: "uji", fetchAsset });
  const e = J(r, "uji_BP/entities/big_zombie.json")["minecraft:entity"];
  assert.equal(e.description.identifier, "hx:big_zombie");
  assert.equal(e.components["minecraft:health"].value, 60);
  assert.equal(e.components["minecraft:attack"].damage, 6);
  assert.ok(e.components["minecraft:behavior.nearest_attackable_target"]);
  const aw = J(r, "uji_BP/items/awmp.json")["minecraft:item"].components;
  assert.equal(aw["minecraft:damage"], 10); assert.equal(aw["minecraft:max_stack_size"], 1);
  const pd = J(r, "uji_BP/items/pedang.json")["minecraft:item"].components;
  assert.equal(pd["minecraft:durability"].max_durability, 30); assert.equal(pd["minecraft:cooldown"].duration, 5);
  const ac = J(r, "uji_RP/animation_controllers/big_zombie.animation_controllers.json");
  const st = Object.values(ac.animation_controllers)[0].states;
  assert.match(st.default.transitions[0].playing, /modified_move_speed/);
  assert.match(st.playing.transitions[0].default, /anim_cancel/);
  assert.equal(J(r, "uji_RP/entity/big_zombie.entity.json")["minecraft:client_entity"].description.animations.hx_anim, "animation.zombie.walk");
  const js = dec(find(r, "uji_BP/scripts/main.js"));
  assert.match(js, /night_vision", 20000000/); assert.match(js, /spawn\(p, "hx:monster"\)/); assert.match(js, /"ammo": "hx:peluru"/);
});

test("damage ++ menambah damage dasar 1", async () => {
  const r = await HX.translate("{item\n name_tag:a\n damage:++7\n}", { name: "x" });
  assert.equal(J(r, "x_BP/items/a.json")["minecraft:item"].components["minecraft:damage"], 8);
});

test("Comma Syntax Rule: campuran ditolak, seragam diterima", async () => {
  await assert.rejects(HX.translate("{item\n name_tag:a\n damage:+1,\n}", {}), (e) => e.name === "HxError" && e.line === 3 && /Comma/.test(e.message));
  await HX.translate("{item\n name_tag:a,\n damage:+1,\n}", { name: "x" });
  await HX.translate("{item\n name_tag:a\n damage:+1\n}", { name: "x" });
});

test("galat: name_tag wajib, kategori salah, max-item di luar 1..64, +give beda", async () => {
  await assert.rejects(HX.translate("{item\n damage:+1\n}", {}), /name_tag/);
  await assert.rejects(HX.translate("{foo\n}", {}), /category/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n max-item:65\n}", {}), /1 to 64/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n +give:b\n}", {}), /\+give/);
  await assert.rejects(HX.translate("{mob\n name_tag:Besar\n}", {}), /lowercase letters/);
});

test("aset hilang tidak menggagalkan build, diganti bawaan dengan peringatan", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n asset://:2610160009\n}", { name: "x", fetchAsset: async () => null });
  assert.ok(r.warnings.some((w) => /not found/.test(w)));
  assert.ok(find(r, "x_RP/textures/entity/m.png")); assert.ok(find(r, "x_RP/models/entity/m.geo.json"));
});

test("ZIP .mcaddon valid dan tekstur png dapat dibaca", async () => {
  const r = await HX.translate(SRC, { name: "uji", fetchAsset });
  const dir = mkdtempSync(join(tmpdir(), "hx-")), z = join(dir, "a.mcaddon");
  writeFileSync(z, HX.zip(r.files));
  try { execFileSync("unzip", ["-tq", z]); } catch (e) { if (e.code === "ENOENT") return; throw e; }
});

/* ---------- sistem dari "Unimplemented Features" ---------- */
const PLANE = readFileSync(new URL("./plane.hx", import.meta.url), "utf8");
const pf = async (id) => ({ "2611170003": anim, "2611170001": geo, "2611170004": png, "2611170005": png, "2611170006": png }[id] || null);

test("crafting 3x3 menjadi resep shaped; menu_creative:off tanpa resep", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const rc = J(r, "p_BP/recipes/wooden_item.json")["minecraft:recipe_shaped"];
  assert.deepEqual(rc.pattern, ["AA", "A "]);
  assert.equal(rc.key.A.item, "minecraft:oak_planks"); assert.equal(rc.result.item, "hx:wooden_item");
  assert.equal(J(r, "p_BP/items/super_sword.json")["minecraft:item"].description.menu_category.category, "none");
  assert.equal(J(r, "p_BP/items/airplane_egg.json")["minecraft:item"].description.menu_category.category, "equipment");
  assert.ok(!find(r, "p_BP/recipes/super_sword.json"));
  const w = await HX.translate("{item\n name_tag:a\n menu_creative:off\n crafting:1, stick\n}", { name: "x" });
  assert.ok(w.warnings.some((x) => /crafting/.test(x))); assert.ok(!find(w, "x_BP/recipes/a.json"));
  await assert.rejects(HX.translate("{item\n name_tag:a\n crafting:1, stick\n crafting:1, stick\n}", {}), /twice/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n crafting:0, stick\n}", {}), /is invalid/);
});

test("fly, move, lead, kursi pada mob (pesawat)", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const c = J(r, "p_BP/entities/airplane.json")["minecraft:entity"].components;
  assert.ok(c["minecraft:can_fly"] && c["minecraft:movement.fly"] && c["minecraft:navigation.fly"]);
  assert.equal(c["minecraft:physics"].has_gravity, false);
  assert.ok(!c["minecraft:navigation.walk"] && !c["minecraft:behavior.random_stroll"] && !c["minecraft:behavior.random_fly"], "move:off");
  assert.ok(!c["minecraft:leashable"], "lead:none");
  assert.deepEqual(c["minecraft:rideable"].seats.position, [0, 1.2, 0]); assert.ok(c["minecraft:input_air_controlled"]);
  const b = await HX.translate("{mob\n name_tag:kuda\n}", { name: "x" });
  assert.ok(J(b, "x_BP/entities/kuda.json")["minecraft:entity"].components["minecraft:leashable"], "lead bawaan");
  assert.ok(J(b, "x_BP/entities/kuda.json")["minecraft:entity"].components["minecraft:behavior.random_stroll"]);
  await assert.rejects(HX.translate("{mob\n name_tag:a\n fly:maybe\n}", {}), /on or off/);
  await assert.rejects(HX.translate("{mob\n name_tag:a\n seat_count:1\n seat_position:0, 1\n}", {}), /is invalid/);
});

test("state mob (flaying) dan pemain (user/player == jumpht) untuk animasi", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const st = Object.values(J(r, "p_RP/animation_controllers/airplane.animation_controllers.json").animation_controllers)[0].states;
  assert.equal(st.default.transitions[0].playing, "(!query.is_on_ground) && !query.property('hx:anim_cancel')");
  assert.equal(st.playing.transitions[0].default, "query.property('hx:anim_cancel')");
  // user dan player = pemain yang sama: hasilnya identik
  const r2 = await HX.translate(PLANE.replace("user == jumpht", "player == jumpht"), { name: "p", fetchAsset: pf });
  const ctl = (x) => dec(find(x, "p_RP/animation_controllers/airplane.animation_controllers.json"));
  assert.equal(ctl(r2), ctl(r));
});

test("icon:// dipakai sebagai ikon item; mob dengan icon:// diberi peringatan", async () => {
  const seen = [];
  const r = await HX.translate("{item\n name_tag:a\n asset_item://:2611170006\n icon://:2611170004\n}\n{mob\n name_tag:m\n icon://:2611170004\n}", { name: "x", fetchAsset: async (id) => { seen.push(id); return png; } });
  assert.ok(seen.includes("2611170004")); assert.ok(!seen.includes("2611170006"), "icon:// didahulukan");
  assert.ok(r.warnings.some((w) => /mobs have no inventory icon/.test(w)));
});

test("custom player + mode, klik kanan/kiri, sit/stand, user == sit", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const js = dec(find(r, "p_BP/scripts/main.js"));
  assert.match(js, /playerSpawn/); assert.match(js, /p\.name\.toLowerCase\(\) === "fadhil"/); assert.match(js, /gamemode creative/);
  assert.match(js, /click === "right"/); assert.match(js, /sit\(p, target\)/); assert.match(js, /stand\(p\)/); assert.match(js, /isRiding\(p\)/);
  assert.match(js, /playerInteractWithEntity/); assert.match(js, /onClick\(p, "left"/);
  const l = await HX.translate("{costum\n name_user:Budi\n}\n{item\n name_tag:a\n}\nif(Budi == host){\n mode:spectator\n}\nif(user == left_click){\n stand\n}", { name: "x" });
  assert.match(dec(find(l, "x_BP/scripts/main.js")), /"budi"/);
  await assert.rejects(HX.translate("{costum\n}", {}), /name_user/);
  const bad = await HX.translate("{item\n name_tag:a\n}\nif(ghost == host){\n mode:creative\n}", { name: "x" });
  assert.ok(bad.warnings.some((w) => /costum/.test(w)));
});

test("{setup}: versi, deskripsi, ikon mod, versi Minecraft", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const bp = J(r, "p_BP/manifest.json"), rp = J(r, "p_RP/manifest.json");
  assert.deepEqual(bp.header.min_engine_version, [1, 26, 10]); assert.equal(rp.header.description, "Airplane Mod created by Fadhil Badhillah and Nava x team");
  assert.ok(find(r, "p_BP/pack_icon.png") && find(r, "p_RP/pack_icon.png"));
  assert.ok(r.warnings.some((w) => /maximum/.test(w)));
  const v = await HX.translate("{setup\n version_mod:2.3.4\n}\n{mob\n name_tag:a\n}", { name: "x" });
  assert.deepEqual(J(v, "x_BP/manifest.json").header.version, [2, 3, 4]);
  assert.deepEqual(J(v, "x_BP/manifest.json").dependencies[0].version, [2, 3, 4]);
  await assert.rejects(HX.translate("{setup\n version_minecraft_support:26.50 and 26.10\n}\n{mob\n name_tag:a\n}", {}), /minimum/);
  for (const bad of ["1.26", "1.50", "26.5x", "27.0.1", "2.0"]) await assert.rejects(HX.translate("{setup\n version_minecraft_support:" + bad + "\n}\n{mob\n name_tag:a\n}", {}), /official|is invalid/, bad);
  const ok = await HX.translate("{setup\n version_minecraft_support:26.50\n}\n{mob\n name_tag:a\n}", { name: "x" });
  assert.ok(!ok.warnings.some((w) => /version/.test(w)), "26.50 resmi tanpa peringatan");
  assert.ok((await HX.translate("{setup\n version_minecraft_support:26.44\n}\n{mob\n name_tag:a\n}", { name: "x" })).warnings.some((w) => /official Bedrock version list/.test(w)));
  assert.deepEqual(J(await HX.translate("{setup\n version_minecraft_support:1.21.130\n}\n{mob\n name_tag:a\n}", { name: "x" }), "x_BP/manifest.json").header.min_engine_version, [1, 21, 130]);
  await assert.rejects(HX.translate("{setup\n version_mod:1.0\n}\n{mob\n name_tag:a\n}", {}), /is invalid/);
  await assert.rejects(HX.translate("{setup\n}\n{setup\n}\n{mob\n name_tag:a\n}", {}), /only one/);
  const lo = await HX.translate("{setup\n version_minecraft_support:1.19.50\n}\n{mob\n name_tag:a\n}", { name: "x" });
  assert.deepEqual(J(lo, "x_BP/manifest.json").header.min_engine_version, [1, 20, 80]);
});

test("contoh gabungan Airplane Mod dari spesifikasi menghasilkan semua file dengan JSON valid", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  for (const f of r.files) if (f.path.endsWith(".json")) JSON.parse(dec(f));
  assert.ok(r.summary.recipes === 1 && r.summary.mobs === 1);
});

test("pemain melompat/bergerak membatalkan animasi mob di tengah jalan (properti + skrip)", async () => {
  const r = await HX.translate(PLANE, { name: "p", fetchAsset: pf });
  const e = J(r, "p_BP/entities/airplane.json")["minecraft:entity"].description;
  assert.deepEqual(e.properties["hx:anim_cancel"], { type: "bool", default: false, client_sync: true });
  const js = dec(find(r, "p_BP/scripts/main.js"));
  assert.match(js, /"hx:airplane": \[\s*"jumpht"\s*\]/); assert.match(js, /p\.isJumping/); assert.match(js, /setProperty\("hx:anim_cancel"/);
  // else(jumpht === move) tanpa subjek = pemain melompat atau bergerak
  const z = await HX.translate(SRC, { name: "uji", fetchAsset });
  assert.match(dec(find(z, "uji_BP/scripts/main.js")), /"hx:big_zombie": \[\s*"jumpht",\s*"move"\s*\]/);
  // tanpa kondisi pemain, tidak ada properti maupun skrip pembatal
  const n = await HX.translate("{mob\n name_tag:m\n animation://:2610160006\n}\nif(m == move){\n start_animation://:2610160006\n}", { name: "x", fetchAsset });
  assert.ok(!J(n, "x_BP/entities/m.json")["minecraft:entity"].description.properties);
  assert.ok(!find(n, "x_BP/scripts/main.js"));
});

/* ---------- === (OR), {user}, {Custom}, bed ---------- */
const BED = `{user
    user_1:user
    user_2:user
    user_3:host_user
}

{Custom
    red_bed:user_1
    point = 0
}

{custom
    blue_bed:user_2
    point = 0
}

if(red_bed == destroy ){
    user_1.mode:spectator
}elif(blue_bed == destroy){
    user_2.mode:spectator
}

if(user_N == destroying bed){
    poin + 1
}
`;
const mainJs = (r) => dec(find(r, "bed_BP/scripts/main.js"));

test("=== dipakai sebagai OR dan ## ditolak", async () => {
  const base = "{item\n    name_tag:x\n}\n";
  const ok = await HX.translate(base + "if(x == on === x == right_click){\n    effect:night_vision infinite\n}\n", { name: "or", fetchAsset });
  assert.match(dec(find(ok, "or_BP/scripts/main.js")), /\|\|/);
  await assert.rejects(() => HX.translate(base + "if(jumpht ## move){\n    animation:cancel\n}\n", { name: "or", fetchAsset }), /replaced by ===/);
});

test("{user}, {Custom}/{custom}, destroy, destroying bed, poin, user_N.mode", async () => {
  const r = await HX.translate(BED, { name: "bed", fetchAsset });
  const js = mainJs(r);
  assert.match(js, /blk === "minecraft:red_bed"/);
  assert.match(js, /withSlot\("user_1", \(q\) => q\.runCommand\("gamemode spectator"\)\)/);
  assert.match(js, /slotOf\(p\) !== null && isBed\(blk\)/);
  assert.match(js, /addPoint\(p, 1\)/);
  assert.match(js, /"user_3": "host_user"/);
});

test("{user}/{Custom} salah ditolak dengan nomor baris", async () => {
  await assert.rejects(() => HX.translate(BED.replace("user_3:host_user", "user_3:admin"), { name: "bed", fetchAsset }), /user or host_user/);
  await assert.rejects(() => HX.translate(BED.replace("red_bed:user_1", "red_bed:user_9"), { name: "bed", fetchAsset }), /is not declared in \{user/);
  await assert.rejects(() => HX.translate(BED.replace("user_1:user\n", "user_1:user,\n"), { name: "bed", fetchAsset }), /Comma Syntax Rule/);
});

/* ---------- Perbaikan bug add-on "Fire" (ikon, onClick kosong, efek milik HX, versi engine) ---------- */
// Menjalankan main.js hasil generate di runtime @minecraft/server tiruan, supaya perilaku (bukan hanya teks) teruji.
function runMain(js) {
  const sub = () => { const l = []; return { l, subscribe: (f) => l.push(f) }; };
  const ev = { itemUse: sub(), playerInteractWithEntity: sub(), entityHitEntity: sub(), playerSpawn: sub(), playerBreakBlock: sub() };
  const intervals = [], players = [];
  const world = { afterEvents: ev, getAllPlayers: () => players, getDynamicProperty: () => undefined, setDynamicProperty() {}, scoreboard: { getObjective: () => ({ addScore() {}, setScore() {} }), addObjective: () => ({ addScore() {}, setScore() {} }) } };
  const system = { runInterval: (f) => intervals.push(f), run: (f) => f() };
  new Function("__mc", js.replace(/^import .*$/m, "const { world, system, EquipmentSlot } = __mc;"))({ world, system, EquipmentSlot: { Mainhand: "Mainhand" } });
  const tick = () => intervals.forEach((f) => f());
  const player = (held) => {
    const p = { id: "p1", typeId: "minecraft:player", effects: new Map(), tags: new Set(), held, cmds: [],
      getComponent: (n) => n === "equippable" ? { getEquipment: () => (p.held ? { typeId: p.held } : undefined) } : undefined,
      addEffect(n, d) { p.effects.set(n, { duration: d }); }, removeEffect(n) { p.effects.delete(n); }, getEffect: (n) => p.effects.get(n),
      hasTag: (t) => p.tags.has(t), addTag: (t) => p.tags.add(t), removeTag: (t) => p.tags.delete(t), getTags: () => [...p.tags],
      runCommand(c) { p.cmds.push(c); }, sendMessage() {}, name: "Steve" };
    players.push(p); return p;
  };
  return { ev, tick, player };
}
const FIRE = "{setup\n version_minecraft_support:26.62\n}\n{item\n name_tag:god_sword\n damage:+20\n hp_item:500 hp\n}\nif(god_sword == on){\n effect:night_vision infinite\n}else{\n effect:night_vision off\n}";
const fireJs = async (src = FIRE) => dec(find(await HX.translate(src, { name: "Fire" }), "Fire_BP/scripts/main.js"));

test("BUG 1: minecraft:icon memakai textures.default dan cocok dengan item_texture.json", async () => {
  const r = await HX.translate(FIRE, { name: "Fire", fetchAsset: async () => png });
  const item = J(r, "Fire_BP/items/god_sword.json"), icon = item["minecraft:item"].components["minecraft:icon"];
  assert.deepEqual(icon, { textures: { default: "god_sword" } });
  assert.ok(!("texture" in icon), "parameter texture sudah dihapus sejak format_version 1.20.60");
  assert.ok(item.format_version >= "1.20.60");
  const tex = J(r, "Fire_RP/textures/item_texture.json").texture_data;
  assert.ok(tex[icon.textures.default], "shortname ikon harus ada di item_texture.json");
  assert.equal(tex.god_sword.textures, "textures/items/god_sword");
  assert.ok(find(r, "Fire_RP/textures/items/god_sword.png"));
});

test("BUG 2: tanpa kondisi klik tidak ada fungsi onClick kosong; fitur item lain tetap jalan", async () => {
  const js = await fireJs();
  assert.doesNotMatch(js, /onClick/); assert.doesNotMatch(js, /playerInteractWithEntity/);
  assert.match(js, /world\.afterEvents\.itemUse\.subscribe/); assert.match(js, /entityHitEntity/); assert.match(js, /wear\(p\)/);
  new Function("__mc", js.replace(/^import .*$/m, "")); // sintaks valid
});

test("BUG 2: kondisi klik tetap diterjemahkan; kanan/kiri dan item lain dipisah", async () => {
  const js = await fireJs("{item\n name_tag:god_sword\n}\n{item\n name_tag:wand\n}\nif(god_sword == right_click){\n mode:creative\n}\nif(user == left_click){\n stand\n}");
  assert.match(js, /function onClick\(p, click, id, target\)/);
  const { ev, player } = runMain(js), p = player("hx:wand");
  ev.itemUse.l[0]({ source: p, itemStack: { typeId: "hx:wand" } });
  assert.deepEqual(p.cmds, [], "klik kanan memakai item lain tidak boleh menjalankan perintah god_sword");
  ev.itemUse.l[0]({ source: p, itemStack: { typeId: "hx:god_sword" } });
  assert.deepEqual(p.cmds, ["gamemode creative"]);
  p.cmds.length = 0; p.held = "hx:wand";
  ev.entityHitEntity.l[0]({ damagingEntity: p, hitEntity: {} });
  assert.deepEqual(p.cmds, ["ride @s stop_riding"], "klik kiri menjalankan stand, bukan blok klik kanan");
  p.cmds.length = 0;
  ev.entityHitEntity.l[0]({ damagingEntity: { typeId: "minecraft:zombie" }, hitEntity: {} });
  assert.deepEqual(p.cmds, [], "serangan non-pemain diabaikan");
});

test("BUG 2: sit/stand pada if(user == right_click){sit}else{stand} (sintaks asli) tetap bekerja", async () => {
  const js = await fireJs("{mob_netral\n name_tag:plane\n seat_count:1\n}\nif(user == right_click){\n sit\n}else{\n stand\n}");
  const { ev, player } = runMain(js), p = player(""), riders = [];
  ev.playerInteractWithEntity.l[0]({ player: p, itemStack: undefined, target: { typeId: "hx:plane", getComponent: () => ({ addRider: (x) => riders.push(x) }) } });
  assert.equal(riders.length, 1);
  ev.entityHitEntity.l[0]({ damagingEntity: p, hitEntity: {} });
  assert.ok(p.cmds.includes("ride @s stop_riding"));
});

test("BUG 3: Night Vision dari God Sword aktif saat dipegang dan hanya efek miliknya yang dimatikan", async () => {
  const { tick, player } = runMain(await fireJs()), p = player("hx:god_sword");
  tick(); assert.ok(p.effects.has("night_vision")); assert.equal(p.effects.get("night_vision").duration, 20000000);
  p.effects.set("speed", { duration: 500 }); p.held = "minecraft:stick"; tick();
  assert.ok(!p.effects.has("night_vision"), "Night Vision milik pedang dimatikan");
  assert.ok(p.effects.has("speed"), "efek lain tidak ikut terhapus");
  assert.deepEqual(p.getTags(), [], "tag kepemilikan dibersihkan");
});

test("BUG 3: Night Vision dari sumber lain (ramuan) tidak dihapus dan tidak ditimpa", async () => {
  const { tick, player } = runMain(await fireJs()), p = player("minecraft:stick");
  p.effects.set("night_vision", { duration: 3000 }); // ramuan
  tick(); assert.ok(p.effects.has("night_vision"), "tidak dipegang: ramuan tidak boleh hilang");
  p.held = "hx:god_sword"; tick();
  assert.equal(p.effects.get("night_vision").duration, 3000, "efek ramuan tidak ditimpa");
  assert.deepEqual(p.getTags(), [], "HX tidak mengklaim efek yang bukan miliknya");
  p.held = "minecraft:stick"; tick(); assert.ok(p.effects.has("night_vision"));
  p.effects.delete("night_vision"); p.held = "hx:god_sword"; tick(); // ramuan habis: pedang mengambil alih
  assert.equal(p.effects.get("night_vision").duration, 20000000);
});

test("BUG 3: tag kedaluwarsa (susu, mati, efek diganti ramuan) tidak membuat efek asing terhapus", async () => {
  const { tick, player } = runMain(await fireJs()), p = player("hx:god_sword");
  tick(); p.effects.delete("night_vision"); // susu / mati menghapus efek, tag tertinggal
  p.held = "minecraft:stick"; p.effects.set("night_vision", { duration: 2400 }); // lalu minum ramuan
  tick(); assert.ok(p.effects.has("night_vision")); assert.deepEqual(p.getTags(), []);
  const q = player("hx:god_sword"); q.id = "p2"; tick();
  q.effects.set("night_vision", { duration: 2400 }); q.held = "x"; tick(); // efek milik HX diganti ramuan saat pedang dipegang
  assert.ok(q.effects.has("night_vision"), "efek ramuan pengganti tetap ada");
});

test("BUG 3: effect:... off di blok lain hanya mematikan efek buatan HX; off tanpa pemberi diberi peringatan", async () => {
  const src = "{item\n name_tag:god_sword\n}\nif(god_sword == on){\n effect:night_vision infinite\n}\nif(user == right_click){\n effect:night_vision off\n}";
  const { ev, tick, player } = runMain(await fireJs(src)), p = player("hx:god_sword");
  tick(); assert.ok(p.effects.has("night_vision"));
  ev.itemUse.l[0]({ source: p, itemStack: { typeId: "hx:god_sword" } });
  assert.ok(!p.effects.has("night_vision"), "off lintas-blok mematikan efek milik HX");
  p.effects.set("night_vision", { duration: 900 }); p.held = "x";
  ev.itemUse.l[0]({ source: p, itemStack: { typeId: "x" } });
  assert.ok(p.effects.has("night_vision"), "efek asing selamat");
  const w = await HX.translate("{item\n name_tag:a\n}\nif(user == right_click){\n effect:slowness off\n}", { name: "x" });
  assert.ok(w.warnings.some((m) => /slowness off turns nothing off/.test(m)));
});

test("BUG 3: efek berdurasi (Ns) tetap diberikan dan dikelola per blok", async () => {
  const js = await fireJs("{item\n name_tag:a\n}\nif(user == right_click){\n effect:speed 5s\n}");
  const { ev, tick, player } = runMain(js), p = player("");
  ev.itemUse.l[0]({ source: p, itemStack: { typeId: "hx:a" } });
  assert.equal(p.effects.get("speed").duration, 100);
  p.effects.delete("speed"); tick(); assert.deepEqual(p.getTags(), [], "tag dibersihkan setelah efek habis");
});

test("BUG 4: min_engine_version sama di BP dan RP, 26.62 -> [1, 26, 62] (penomoran Bedrock 26.x)", async () => {
  const r = await HX.translate(FIRE, { name: "Fire" });
  const bp = J(r, "Fire_BP/manifest.json"), rp = J(r, "Fire_RP/manifest.json");
  assert.deepEqual(bp.header.min_engine_version, [1, 26, 62]); assert.deepEqual(rp.header.min_engine_version, [1, 26, 62]);
  assert.equal(bp.dependencies[0].uuid, rp.header.uuid, "UUID RP di dependensi BP cocok");
  assert.ok(bp.modules.some((m) => m.type === "script"));
  assert.ok(!r.warnings.some((m) => /version/.test(m)), "26.62 ada di daftar versi resmi");
});

test("item tetap memuat minecraft:hand_equipped bersama ikon (regresi: komentar tidak boleh menelan pernyataan di belakangnya)", async () => {
  const r = await HX.translate(FIRE, { name: "Fire", fetchAsset: async () => png });
  const c = J(r, "Fire_BP/items/god_sword.json")["minecraft:item"].components;
  assert.equal(c["minecraft:hand_equipped"], true);
  assert.deepEqual(c["minecraft:icon"], { textures: { default: "god_sword" } });
});

test("model 3D mob (geo, tekstur, animasi, entity klien) tidak terpengaruh perbaikan item/skrip", async () => {
  const g = new TextEncoder().encode(JSON.stringify({ format_version: "1.12.0", "minecraft:geometry": [{ description: { identifier: "geometry.zombie" }, bones: [] }] }));
  const r = await HX.translate(SRC, { name: "x", fetchAsset });
  assert.ok(find(r, "x_RP/models/entity/big_zombie.geo.json")); assert.ok(find(r, "x_RP/textures/entity/big_zombie.png"));
  const ce = J(r, "x_RP/entity/big_zombie.entity.json")["minecraft:client_entity"].description;
  assert.equal(ce.geometry.default, "geometry.zombie"); assert.equal(ce.textures.default, "textures/entity/big_zombie");
  void g;
});

/* ---------- Model 3D item (attachable) ---------- */
const bladeGeo = new TextEncoder().encode(JSON.stringify({ format_version: "1.12.0", "minecraft:geometry": [{ description: { identifier: "geometry.blade", texture_width: 32, texture_height: 32 }, bones: [{ name: "root", pivot: [0, 0, 0], cubes: [{ origin: [-1, 0, -1], size: [2, 12, 2], uv: [0, 0] }] }, { name: "guard", parent: "root", pivot: [0, 4, 0], cubes: [{ origin: [-3, 4, -1], size: [6, 1, 2], uv: [0, 0] }] }] }] }));
const legacyGeo = new TextEncoder().encode(JSON.stringify({ format_version: "1.8.0", "geometry.old": { texturewidth: 16, textureheight: 16, bones: [{ name: "a", pivot: [0, 0, 0], cubes: [{ origin: [0, 0, 0], size: [1, 1, 1], uv: [0, 0] }] }] } }));
const itemFetch = async (id) => ({ "2610160001": png, "2610160002": bladeGeo, "2610160004": legacyGeo }[id] || null);
const BLADE = "{item\n name_tag:blade\n asset://:2610160002\n asset://:2610160001\n}";

test("item dengan asset geo -> attachable (geometri diikat ke tangan, ikon 2D tetap, tekstur dari png)", async () => {
  const r = await HX.translate(BLADE, { name: "x", fetchAsset: itemFetch });
  const at = J(r, "x_RP/attachables/blade.attachable.json")["minecraft:attachable"].description;
  assert.equal(at.identifier, "hx:blade"); assert.equal(at.geometry.default, "geometry.hx_item_blade");
  assert.equal(at.textures.default, "textures/attachables/blade"); assert.deepEqual(at.render_controllers, ["controller.render.item_default"]);
  const g = J(r, "x_RP/models/entity/blade.item.geo.json")["minecraft:geometry"][0];
  assert.equal(g.description.identifier, "geometry.hx_item_blade");
  assert.equal(g.bones[0].binding, "q.item_slot_to_bone_name(context.item_slot)"); assert.equal(g.bones[1].binding, undefined, "hanya bone akar yang diikat");
  assert.equal(J(r, "x_BP/items/blade.json")["minecraft:item"].components["minecraft:icon"].textures.default, "blade");
  assert.ok(find(r, "x_RP/textures/attachables/blade.png")); assert.ok(find(r, "x_RP/textures/items/blade.png"));
  assert.ok(!r.warnings.some((w) => /is not a png image/.test(w))); assert.ok(r.warnings.some((w) => /attachable/.test(w)));
});

test("item dengan geo tanpa png memakai warna polos + peringatan; format geometri lama didukung", async () => {
  const r = await HX.translate("{item\n name_tag:old\n asset://:2610160004\n}", { name: "x", fetchAsset: itemFetch });
  assert.ok(r.warnings.some((w) => /3D model of item "old" has no png texture/.test(w)));
  const gj = J(r, "x_RP/models/entity/old.item.geo.json");
  assert.ok(gj["geometry.hx_item_old"] && !gj["geometry.old"]); assert.equal(gj["geometry.hx_item_old"].bones[0].binding, "q.item_slot_to_bone_name(context.item_slot)");
  assert.equal(J(r, "x_RP/attachables/old.attachable.json")["minecraft:attachable"].description.geometry.default, "geometry.hx_item_old");
});

test("item tanpa asset geo tidak menghasilkan attachable; mob dengan geo yang sama tidak berubah", async () => {
  const r = await HX.translate("{item\n name_tag:plain\n asset_item://:2610160001\n}\n{mob\n name_tag:m\n asset://:2610160002\n}\n{item\n name_tag:blade\n asset://:2610160002\n}", { name: "x", fetchAsset: itemFetch });
  assert.ok(!find(r, "x_RP/attachables/plain.attachable.json")); assert.ok(find(r, "x_RP/attachables/blade.attachable.json"));
  assert.equal(dec(find(r, "x_RP/models/entity/m.geo.json")), new TextDecoder().decode(bladeGeo), "geo mob tetap identik dengan aset (tanpa binding)");
  assert.equal(J(r, "x_RP/entity/m.entity.json")["minecraft:client_entity"].description.geometry.default, "geometry.blade");
});

/* ---------- asset dipecah: models, icon_item, start-animation, animation-true-start ---------- */
const nf = async (id) => ({ "2612010001": png, "2612010002": bladeGeo, "2612010003": anim, "2612010004": png }[id] || null);
const ctlOf = (r, n) => Object.values(J(r, "x_RP/animation_controllers/" + n + ".animation_controllers.json").animation_controllers)[0];
const animOf = (r, n) => Object.values(J(r, "x_RP/animations/" + n + ".animation.json").animations)[0];

test("item: models:// = model 3D dipegang, icon_item:// = ikon inventory", async () => {
  const r = await HX.translate("{item\n name_tag:blade\n models://:2612010002\n models://:2612010001\n icon_item://:2612010004\n}", { name: "x", fetchAsset: nf });
  assert.equal(J(r, "x_RP/attachables/blade.attachable.json")["minecraft:attachable"].description.geometry.default, "geometry.hx_item_blade");
  assert.ok(find(r, "x_RP/textures/attachables/blade.png") && find(r, "x_RP/textures/items/blade.png"));
  assert.ok(!r.warnings.some((w) => /is not recognized|is not a png image|texture/.test(w)), r.warnings.join("|"));
  // model tanpa icon_item: ikon polos, bukan tekstur model
  const n = await HX.translate("{item\n name_tag:blade\n models://:2612010002\n models://:2612010001\n}", { name: "x", fetchAsset: nf });
  assert.ok(n.warnings.some((w) => /has no png icon/.test(w)));
  assert.notDeepEqual(find(n, "x_RP/textures/items/blade.png").data, png);
  // icon_item berisi geo -> ditolak jadi ikon dengan peringatan
  const bad = await HX.translate("{item\n name_tag:b\n icon_item://:2612010002\n}", { name: "x", fetchAsset: nf });
  assert.ok(bad.warnings.some((w) => /is not a png image/.test(w)));
});

test("mob: models:// dipakai sebagai model dan tekstur; icon_item diabaikan dengan peringatan", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n models://:2612010002\n models://:2612010001\n icon_item://:2612010004\n}", { name: "x", fetchAsset: nf });
  assert.equal(J(r, "x_RP/entity/m.entity.json")["minecraft:client_entity"].description.geometry.default, "geometry.blade");
  assert.deepEqual(find(r, "x_RP/textures/entity/m.png").data, png);
  assert.ok(r.warnings.some((w) => /icon_item/.test(w)));
});

test("animation-true-start: berulang (loop:true) selama kondisi benar", async () => {
  const src = "{mob\n name_tag:m\n}\nif(m == move){\n animation-true-start://:2612010003\n}";
  const r = await HX.translate(src, { name: "x", fetchAsset: nf });
  assert.equal(animOf(r, "m").loop, true);
  const st = ctlOf(r, "m").states;
  assert.equal(st.default.transitions[0].playing, "query.modified_move_speed > 0.1");
  assert.equal(st.playing.transitions[0].default, "!(query.modified_move_speed > 0.1)"); assert.ok(!st.done);
  assert.ok(!r.warnings.some((w) => /old syntax/.test(w)));
  // loop:false pada aset dipaksa jadi true
  const one = async (id) => id === "2612010003" ? new TextEncoder().encode(JSON.stringify({ animations: { "animation.a": { loop: false } } })) : null;
  assert.equal(animOf(await HX.translate(src, { name: "x", fetchAsset: one }), "m").loop, true);
});

test("start-animation: sekali (loop:false), selesai lalu state done sampai kondisi padam", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n}\nif(m == move){\n start-animation://:2612010003\n}", { name: "x", fetchAsset: nf });
  assert.equal(animOf(r, "m").loop, false, "aset loop:true dipaksa sekali");
  const st = ctlOf(r, "m").states;
  assert.deepEqual(st.playing.transitions, [{ done: "query.all_animations_finished" }]);
  assert.deepEqual(st.done.transitions, [{ default: "!(query.modified_move_speed > 0.1)" }]);
});

test("start-animation dengan animation:cancel dari pemain tetap bisa dibatalkan", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n}\nif(m == move){\n start-animation://:2612010003\n}\nif(user == jumpht){\n animation:cancel\n}", { name: "x", fetchAsset: nf });
  const st = ctlOf(r, "m").states;
  assert.deepEqual(st.playing.transitions, [{ default: "query.property('hx:anim_cancel')" }, { done: "query.all_animations_finished" }]);
  assert.ok(J(r, "x_BP/entities/m.json")["minecraft:entity"].description.properties["hx:anim_cancel"]);
});

test("animasi di dalam {mob (tanpa if) ditolak dengan peringatan, tidak jalan sendiri", async () => {
  for (const k of ["start-animation", "animation-true-start"]) {
    const r = await HX.translate("{mob\n name_tag:m\n " + k + "://:2612010003\n}", { name: "x", fetchAsset: nf });
    assert.ok(r.warnings.some((w) => w.includes(k) && /if block|if\/elif\/else block/.test(w)), r.warnings.join("|"));
    assert.ok(!find(r, "x_RP/animation_controllers/m.animation_controllers.json"), "tanpa if tidak ada controller animasi");
  }
});

test("if / elif / else: animasi berbeda per cabang tidak merusak, cabang cancel tetap bekerja", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n}\nif(m == move){\n animation-true-start://:2612010003\n}\nelif(m == flaying){\n animation:cancel\n}\nelse{\n animation:cancel\n}", { name: "x", fetchAsset: nf });
  assert.equal(animOf(r, "m").loop, true);
  assert.ok(ctlOf(r, "m").states.playing);
});

test("{asset memberi nama ke kode baru, dan sintaks lama start_animation diberi peringatan", async () => {
  const src = "{asset\n name_tag:anim_fly\n animation-true-start://:2612010003\n}\n{asset\n name_tag:mdl\n models://:2612010002\n}\n{mob\n name_tag:m\n models:mdl\n}\nif(m == move){\n animation-true-start:anim_fly\n}";
  const r = await HX.translate(src, { name: "x", fetchAsset: nf });
  assert.equal(animOf(r, "m").loop, true);
  assert.equal(J(r, "x_RP/entity/m.entity.json")["minecraft:client_entity"].description.geometry.default, "geometry.blade");
  assert.ok(!r.warnings.some((w) => /is not recognized/.test(w)), r.warnings.join("|"));
  const old = await HX.translate("{mob\n name_tag:m\n}\nif(m == move){\n start_animation://:2612010003\n}", { name: "x", fetchAsset: nf });
  assert.ok(old.warnings.some((w) => /old syntax/.test(w))); assert.equal(animOf(old, "m").loop, true);
});

test("animasi tanpa aset .animation.json dan blok tanpa mob dikenal tetap diberi peringatan", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n}\nif(m == move){\n start-animation://:2612010004\n}", { name: "x", fetchAsset: nf });
  assert.ok(r.warnings.some((w) => /no \.animation\.json asset/.test(w)));
  const z = await HX.translate("{mob\n name_tag:m\n}\nif(zzz == move){\n animation-true-start://:2612010003\n}", { name: "x", fetchAsset: nf });
  assert.ok(z.warnings.some((w) => /does not mention a known mob/.test(w)));
});

/* ---------- blok percabangan [ ... ] ---------- */
const MOBM = "{mob\n name_tag:m\n}\n";
test("blok [ ] berisi if/else; hasil sama dengan if tanpa blok (blok opsional, tanpa peringatan)", async () => {
  const a = await HX.translate(MOBM + "[\n if(m == move){\n  animation-true-start://:2612010003\n }else{\n  animation:cancel\n }\n]", { name: "x", fetchAsset: nf });
  const b = await HX.translate(MOBM + "if(m == move){\n  animation-true-start://:2612010003\n }else{\n  animation:cancel\n }", { name: "x", fetchAsset: nf });
  assert.deepEqual(ctlOf(a, "m"), ctlOf(b, "m"));
  assert.ok(!a.warnings.some((w) => /outside \[ \]/.test(w)) && !b.warnings.some((w) => /outside \[ \]/.test(w)));
});

test("tiap blok [ ] berdiri sendiri: cancel dari blok lain tidak ikut, dan else tidak menyeberang blok", async () => {
  const same = await HX.translate(MOBM + "[\n if(m == move){\n  start-animation://:2612010003\n }\n if(user == jumpht){\n  animation:cancel\n }\n]", { name: "x", fetchAsset: nf });
  assert.ok(ctlOf(same, "m").states.playing.transitions.some((t) => /anim_cancel/.test(t.default || "")));
  const apart = await HX.translate(MOBM + "[\n if(m == move){\n  start-animation://:2612010003\n }\n]\n[\n if(user == jumpht){\n  animation:cancel\n }\n]", { name: "x", fetchAsset: nf });
  assert.ok(!ctlOf(apart, "m").states.playing.transitions.some((t) => /anim_cancel/.test(t.default || "")));
  await assert.rejects(HX.translate(MOBM + "[\n if(m == move){\n  spawn:m\n }\n]\n[\n else{\n  spawn:m\n }\n]", {}), /must follow an if block/);
});

test("blok [ ] salah bentuk ditolak dengan nomor baris", async () => {
  await assert.rejects(HX.translate(MOBM + "[\n if(m == move){\n  spawn:m\n }\n", {}), /is not closed with \]/);
  await assert.rejects(HX.translate(MOBM + "]\n", {}), /without a matching/);
  await assert.rejects(HX.translate(MOBM + "[\n[\n]\n]\n", {}), /cannot be nested/);
  await assert.rejects(HX.translate(MOBM + "[\n{item\n name_tag:a\n}\n]\n", {}), /cannot be inside a/);
});

test("dua blok animasi untuk mob yang sama diberi peringatan (hanya yang pertama dipakai)", async () => {
  const r = await HX.translate(MOBM + "[\n if(m == move){\n  animation-true-start://:2612010003\n }\n]\n[\n if(m == flaying){\n  start-animation://:2612010003\n }\n]", { name: "x", fetchAsset: nf });
  assert.ok(r.warnings.some((w) => /more than one animation block/.test(w)));
});

/* ---------- animasi pemain (user / player) ---------- */
const pjs = (r, n = "x") => dec(find(r, n + "_BP/scripts/main.js"));
const syntaxOk = (js) => { const d = mkdtempSync(join(tmpdir(), "hx-")), f = join(d, "m.mjs"); writeFileSync(f, js); execFileSync(process.execPath, ["--check", f]); };

test("user == right_click + start-animation: animasi pemain sekali lewat /playanimation", async () => {
  const r = await HX.translate("{item\n name_tag:egg\n}\n[\n if(user == right_click){\n  start-animation://:2612010003\n }\n]", { name: "x", fetchAsset: nf });
  const f = J(r, "x_RP/animations/hx_player_2612010003_once.animation.json");
  assert.deepEqual(Object.keys(f.animations), ["animation.hx_player_2612010003_once"]);
  assert.equal(f.animations["animation.hx_player_2612010003_once"].loop, false);
  assert.ok(find(r, "x_RP/animations/hx_player_empty.animation.json"));
  const js = pjs(r);
  assert.match(js, /playAnim\(p, "animation\.hx_player_2612010003_once", true\)/); assert.match(js, /playanimation @s/); assert.match(js, /controller\.animation\.hx_player/);
  assert.ok(r.warnings.some((w) => /\/playanimation command and have not been tested/.test(w)));
  assert.ok(!find(r, "x_RP/animation_controllers/m.animation_controllers.json"));
  syntaxOk(js);
});

test("player == sit + animation-true-start + else animation:cancel: berulang, dicek berkala, dibatalkan", async () => {
  const r = await HX.translate("{item\n name_tag:egg\n}\n[\n if(player == sit){\n  animation-true-start://:2612010003\n }else{\n  animation:cancel\n }\n]", { name: "x", fetchAsset: nf });
  assert.equal(Object.values(J(r, "x_RP/animations/hx_player_2612010003_loop.animation.json").animations)[0].loop, true);
  const js = pjs(r);
  assert.match(js, /playAnim\(p, "animation\.hx_player_2612010003_loop", false\)/); assert.match(js, /cancelAnim\(p, "animation\.hx_player_empty"\)/);
  syntaxOk(js);
});

test("animasi pemain dan animasi mob bisa dipakai bersamaan tanpa tertukar", async () => {
  const r = await HX.translate("{mob\n name_tag:m\n}\n[\n if(m == move){\n  animation-true-start://:2612010003\n }\n]\n[\n if(user == left_click){\n  start-animation://:2612010003\n }\n]", { name: "x", fetchAsset: nf });
  assert.equal(animOf(r, "m").loop, true);
  assert.ok(find(r, "x_RP/animations/hx_player_2612010003_once.animation.json"));
  syntaxOk(pjs(r));
});

test("animasi pemain: aset salah jenis dan kondisi tak didukung diberi peringatan, tanpa skrip animasi", async () => {
  const bad = await HX.translate("{item\n name_tag:egg\n}\n[\n if(user == right_click){\n  start-animation://:2612010001\n }\n]", { name: "x", fetchAsset: nf });
  assert.ok(bad.warnings.some((w) => /is not an \.animation\.json asset/.test(w)) && !/playAnim\(/.test(pjs(bad)));
  const mv = await HX.translate("{item\n name_tag:egg\n}\n[\n if(user == jumpht){\n  start-animation://:2612010003\n }\n]", { name: "x", fetchAsset: nf });
  assert.ok(mv.warnings.some((w) => /unrecognized|not recognized/.test(w)));
});

/* ---------- touch.<blok> dan effect:off tanpa nama ---------- */
const TOUCHSRC = "{item\n name_tag:egg\n}\n[\n if(user == touch.oak_planks){\n  effect:night_vision infinite\n }else{\n  effect:off\n }\n]";
test("user == touch.nama_blok + effect:off: efek hanya saat menyentuh blok, mati saat tidak", async () => {
  const r = await HX.translate(TOUCHSRC, { name: "x", fetchAsset: nf });
  const js = pjs(r);
  assert.match(js, /touching\(p, "minecraft:oak_planks"\)/); assert.match(js, /function touching/);
  assert.match(js, /fxAdd\(p, "hx_fx_0_night_vision", "night_vision", 20000000\)/);
  assert.match(js, /fxOff\(p, "night_vision", \["hx_fx_0_night_vision"\]\)/);
  assert.ok(!r.warnings.some((w) => /unrecognized|turns nothing off/.test(w)), r.warnings.join("|"));
  syntaxOk(js);
  // dijalankan berkala (tick), bukan hanya saat klik
  assert.match(js, /system\.runInterval\(\(\) => \{\s*for \(const p of world\.getAllPlayers\(\)\)[\s\S]*chain0\(p, "", id, null\)/);
});

test("touch: nama dengan namespace, subjek bukan pemain ditolak, tanpa touch tidak ada fungsi touching", async () => {
  const ns = await HX.translate(TOUCHSRC.replace("touch.oak_planks", "touch.mypack:crate"), { name: "x" });
  assert.match(pjs(ns), /touching\(p, "mypack:crate"\)/);
  const bad = await HX.translate("{mob\n name_tag:m\n}\n[\n if(m == touch.stone){\n  effect:night_vision infinite\n }\n]", { name: "x" });
  assert.ok(bad.warnings.some((w) => /is only for user or player/.test(w)));
  const none = await HX.translate("{item\n name_tag:egg\n}\n[\n if(user == sit){\n  mode:creative\n }\n]", { name: "x" });
  assert.ok(!/function touching/.test(pjs(none)));
});

test("effect:off tanpa nama di blok yang tidak memberi efek diberi peringatan", async () => {
  const r = await HX.translate("{item\n name_tag:egg\n}\n[\n if(user == touch.stone){\n  mode:creative\n }else{\n  effect:off\n }\n]", { name: "x" });
  assert.ok(r.warnings.some((w) => /effect:off without a name/.test(w)));
});

test("kondisi tanpa == ditolak dengan galat yang menyebut baris dan cara menulisnya", async () => {
  await assert.rejects(HX.translate("{mob\n name_tag:m\n}\nif(m move){\n spawn:m\n}\n", {}), (e) => e.name === "HxError" && e.line === 4 && /missing ==/.test(e.message) && /m == move/.test(e.message));
  await assert.rejects(HX.translate("{item\n name_tag:a\n}\nif(user touch.stone){\n spawn:a\n}\n", {}), /missing ==/);
});

test("mob dengan gambar png saja menjadi papan kardus datar (bukan 3D)", async () => {
  const p2 = HX.pngSolid(32, 48, [10, 200, 30]);
  const r = await HX.translate("{mob\n name_tag:kardus\n shape:flat\n models://:2611180001\n}\n", { name: "k", fetchAsset: async () => p2 });
  const g = J(r, "k_RP/models/entity/kardus.geo.json")["minecraft:geometry"][0], c = g.bones[0].cubes[0];
  assert.deepEqual(c.size, [24, 36, 1]);
  assert.equal(g.description.texture_width, 32); assert.equal(g.description.texture_height, 48);
  assert.deepEqual(c.uv.north.uv_size, [32, 48]); assert.deepEqual(c.uv.south.uv_size, [32, 48]);
  assert.ok(r.warnings.some((w) => /flat cardboard cutout/.test(w)));
  assert.ok(!r.warnings.some((w) => /no png texture/.test(w)));
});

test("papan kardus untuk gambar sangat tinggi dibatasi 4 blok tanpa mengubah rasio", async () => {
  const tall = HX.pngSolid(40, 320, [200, 10, 10]);
  const r = await HX.translate("{mob\n name_tag:tinggi\n shape:flat\n models://:2611180003\n}\n", { name: "t", fetchAsset: async () => tall });
  assert.deepEqual(J(r, "t_RP/models/entity/tinggi.geo.json")["minecraft:geometry"][0].bones[0].cubes[0].size, [8, 64, 1]);
});

test("mob dari gambar png saja menjadi model bulat 3D dengan siluet gambar (lathe)", async () => {
  const rk = new Uint8Array(readFileSync(new URL("./rocket-small.png", import.meta.url)));
  const r = await HX.translate("{mob_netral\n name_tag:roket\n models://:2611180004\n}\n", { name: "r", fetchAsset: async () => rk });
  const g = J(r, "r_RP/models/entity/roket.geo.json")["minecraft:geometry"][0], cubes = g.bones[0].cubes;
  assert.ok(cubes.length >= 8 && cubes.length % 8 === 0, "8 papan per irisan");
  assert.ok(cubes.length <= 16 * 8, "maksimal 16 irisan supaya tidak lag");
  assert.ok(cubes.every((q) => Object.keys(q.uv).join() === "north"), "hanya sisi depan yang digambar");
  const widths = cubes.map((q) => q.size[0]), top = widths.slice(0, 8), mid = widths.slice(cubes.length / 2 - 4, cubes.length / 2 + 4);
  assert.ok(Math.max(...top) < Math.max(...mid) * 0.7, "ujung hidung lebih sempit dari badan");
  assert.ok(Math.max(...cubes.map((q) => q.origin[1] + q.size[1])) <= 64.001, "tinggi maksimal 4 blok");
  assert.ok(cubes.some((q) => q.rotation && q.rotation[1] === 135));
  assert.ok(r.warnings.some((w) => /round 3D model/.test(w)));
  assert.ok(!r.warnings.some((w) => /no transparent background/.test(w)));
});

test("gambar png tanpa latar transparan menjadi kolom bulat dan diberi peringatan", async () => {
  const r = await HX.translate("{mob\n name_tag:kolom\n models://:2611180005\n}\n", { name: "k", fetchAsset: async () => HX.pngSolid(32, 32, [9, 9, 9]) });
  const cubes = J(r, "k_RP/models/entity/kolom.geo.json")["minecraft:geometry"][0].bones[0].cubes;
  assert.ok(cubes.length >= 8);
  assert.ok(r.warnings.some((w) => /no transparent background/.test(w)));
});

test("shape: nilai tidak dikenal diberi peringatan dan memakai round", async () => {
  const r = await HX.translate("{mob\n name_tag:x\n shape:sphere\n models://:2611180006\n}\n", { name: "s", fetchAsset: async () => HX.pngSolid(16, 16, [1, 2, 3]) });
  assert.ok(r.warnings.some((w) => /shape:sphere is not recognized/.test(w)));
});

// ---- skin Minecraft -> model humanoid
const skinFile = (n) => new Uint8Array(readFileSync(new URL("./" + n, import.meta.url)));
const mobSkin = async (n, extra = "", opts = {}) => HX.translate("{mob\n name_tag:steve\n" + extra + " models://:2611190001\n}\n", { name: "sk", fetchAsset: async () => skinFile(n), ...opts });
const skinGeo = (r) => J(r, "sk_RP/models/entity/steve.geo.json")["minecraft:geometry"][0];
const bonesOf = (g) => Object.fromEntries(g.bones.map((b) => [b.name, b]));

test("png skin 64x64 otomatis menjadi model manusia lengkap dengan lapisan luar", async () => {
  const r = await mobSkin("skin-64.png"), g = skinGeo(r), b = bonesOf(g);
  assert.deepEqual(["head", "body", "rightArm", "leftArm", "rightLeg", "leftLeg"].filter((n) => !b[n]), []);
  assert.deepEqual(b.head.cubes[0].size, [8, 8, 8]); assert.deepEqual(b.head.cubes[0].uv, [0, 0]);
  assert.deepEqual(b.body.cubes[0].size, [8, 12, 4]); assert.deepEqual(b.body.cubes[0].uv, [16, 16]);
  assert.deepEqual(b.rightArm.cubes[0].uv, [40, 16]); assert.deepEqual(b.leftArm.cubes[0].uv, [32, 48]);
  assert.deepEqual(b.rightLeg.cubes[0].uv, [0, 16]); assert.deepEqual(b.leftLeg.cubes[0].uv, [16, 48]);
  assert.equal(b.rightArm.cubes[0].size[0], 4);
  assert.equal(b.hat.parent, "head"); assert.equal(b.hat.cubes[0].inflate, 0.5); assert.deepEqual(b.hat.cubes[0].uv, [32, 0]);
  assert.equal(b.jacket.parent, "body");
  assert.ok(!b.rightSleeve && !b.leftSleeve && !b.rightPants && !b.leftPants, "lapisan yang transparan penuh dilewati");
  assert.equal(g.description.texture_width, 64); assert.equal(g.description.texture_height, 64);
  const tex = find(r, "sk_RP/textures/entity/steve.png").data; assert.equal(tex.length, skinFile("skin-64.png").length);
  assert.ok(r.warnings.some((w) => /humanoid model/.test(w)));
  assert.ok(!r.warnings.some((w) => /round 3D model|flat cardboard/.test(w)));
});

test("model manusia memakai geometri dan animasi jalan di entity klien", async () => {
  const r = await mobSkin("skin-64.png"), ce = J(r, "sk_RP/entity/steve.entity.json")["minecraft:client_entity"].description;
  assert.equal(ce.geometry.default, skinGeo(r).description.identifier);
  assert.deepEqual(ce.scripts.animate, ["hx_walk"]);
  const wk = J(r, "sk_RP/animations/steve.walk.animation.json").animations[ce.animations.hx_walk];
  assert.ok(wk.loop && wk.bones.rightArm && wk.bones.leftLeg && wk.bones.head);
  assert.equal(ce.materials.default, "entity_alpha");
});

test("skin 512x512 tetap memakai ruang UV 64 (Minecraft menskalakan sendiri)", async () => {
  const r = await mobSkin("skin-512.png"), g = skinGeo(r);
  assert.equal(g.description.texture_width, 64); assert.equal(g.description.texture_height, 64);
  assert.ok(bonesOf(g).jacket && bonesOf(g).hat);
  assert.equal(find(r, "sk_RP/textures/entity/steve.png").data.length, skinFile("skin-512.png").length);
});

test("skin lama 64x32: kaki dan tangan kiri mencerminkan yang kanan, tanpa jaket", async () => {
  const r = await mobSkin("skin-legacy.png"), g = skinGeo(r), b = bonesOf(g);
  assert.equal(g.description.texture_height, 32);
  assert.deepEqual(b.leftArm.cubes[0].uv, [40, 16]); assert.equal(b.leftArm.cubes[0].mirror, true);
  assert.deepEqual(b.leftLeg.cubes[0].uv, [0, 16]); assert.equal(b.leftLeg.cubes[0].mirror, true);
  assert.ok(!b.rightArm.cubes[0].mirror && !b.jacket && !b.rightSleeve);
  assert.ok(r.warnings.some((w) => /old 64x32 skin/.test(w)));
});

test("skin tanpa piksel transparan: lapisan luar dilewati dan diberi peringatan", async () => {
  const r = await mobSkin("skin-opaque.png"), b = bonesOf(skinGeo(r));
  assert.ok(!b.hat && !b.jacket);
  assert.ok(r.warnings.some((w) => /no transparent pixels/.test(w)));
});

test("skin lengan ramping (Alex) terdeteksi otomatis, atau dipaksa dengan shape:slim", async () => {
  const b1 = bonesOf(skinGeo(await mobSkin("skin-slim.png")));
  assert.equal(b1.rightArm.cubes[0].size[0], 3); assert.equal(b1.leftArm.cubes[0].size[0], 3);
  assert.deepEqual(b1.rightArm.cubes[0].origin, [-7, 12, -2]); assert.deepEqual(b1.rightArm.pivot, [-5, 21.5, 0]);
  const b2 = bonesOf(skinGeo(await mobSkin("skin-64.png", " shape:slim\n")));
  assert.equal(b2.rightArm.cubes[0].size[0], 3);
  const b3 = bonesOf(skinGeo(await mobSkin("skin-slim.png", " shape:humanoid\n")));
  assert.equal(b3.rightArm.cubes[0].size[0], 4);
});

test("shape:round pada png berukuran skin tetap memberi model bulat; shape:humanoid pada gambar lain ditolak halus", async () => {
  const r = await mobSkin("skin-64.png", " shape:round\n");
  assert.ok(r.warnings.some((w) => /round 3D model/.test(w)) && !bonesOf(skinGeo(r)).head);
  const r2 = await HX.translate("{mob\n name_tag:steve\n shape:humanoid\n models://:2611190002\n}\n", { name: "sk", fetchAsset: async () => HX.pngSolid(40, 40, [9, 9, 9]) });
  assert.ok(r2.warnings.some((w) => /needs a Minecraft skin png/.test(w)) && !bonesOf(skinGeo(r2)).head);
});

test("shape:humanoid tanpa gambar memakai tubuh manusia dengan warna polos", async () => {
  const r = await HX.translate("{mob\n name_tag:steve\n shape:humanoid\n}\n", { name: "sk" });
  assert.ok(bonesOf(skinGeo(r)).rightLeg);
});

test("kerangka animasi buatan pengguna tidak ditimpa animasi jalan bawaan", async () => {
  const src2 = "{mob\n name_tag:steve\n models://:2611190001\n}\nif(steve == move){\n animation-true-start://:2611190003\n}\n";
  const r = await HX.translate(src2, { name: "sk", fetchAsset: async (id) => (id === "2611190003" ? anim : skinFile("skin-64.png")) });
  assert.ok(bonesOf(skinGeo(r)).head);
  assert.ok(!find(r, "sk_RP/animations/steve.walk.animation.json"));
});

test("gambar JPG diubah ke png lewat imageToPng; tanpa itu diberi peringatan", async () => {
  const jpg = skinFile("skin.jpg"), png = skinFile("skin-64.png");
  let called = 0;
  const r = await HX.translate("{mob\n name_tag:steve\n models://:2611190001\n}\n", { name: "sk", fetchAsset: async () => jpg, imageToPng: async () => { called++; return png; } });
  assert.equal(called, 1); assert.ok(bonesOf(skinGeo(r)).head);
  assert.ok(r.warnings.some((w) => /JPG image: it was converted/.test(w)));
  const r2 = await HX.translate("{mob\n name_tag:steve\n models://:2611190001\n}\n", { name: "sk", fetchAsset: async () => jpg });
  assert.ok(r2.warnings.some((w) => /could not be converted here; save it as png/.test(w)));
});

// ---- attack_effect
const SWORD = "{item\n name_tag:pedang\n damage:+8\n}\n";
const jsOf = (r) => dec(find(r, "a_BP/scripts/main.js"));
test("if(pedang == attack){ attack_effect: poison } memberi effect ke yang dipukul", async () => {
  const r = await HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison\n}\n", { name: "a" }), js = jsOf(r);
  assert.match(js, /hitEffect\(target, "poison", 200\);/);
  assert.match(js, /id === "[a-z0-9_]+:pedang"/);
  assert.match(js, /function hitEffect\(t, name, ticks, amp\)/);
  assert.match(js, /entityHitEntity[\s\S]*chain\d+\(p, "", id, target\)/);
  assert.ok(!r.warnings.some((w) => /unrecognized/.test(w)));
});

test("attack_effect menerima durasi, beberapa effect, dan blok [ ]", async () => {
  const r = await HX.translate(SWORD + "[\n if(pedang == attack){\n  attack_effect: wither 5s\n  attack_effect: SLOWNESS 2.5s\n }\n]\n", { name: "a" }), js = jsOf(r);
  assert.match(js, /hitEffect\(target, "wither", 100\);/); assert.match(js, /hitEffect\(target, "slowness", 50\);/);
});

test("attack_effect dengan nama effect yang bukan resmi ditolak dan menyarankan nama dekat", async () => {
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: racun\n}\n", { name: "a" }), (e) => e.name === "HxError" && e.line === 6 && /not an official Minecraft effect/.test(e.message) && /poison/.test(e.message));
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: pois\n}\n", { name: "a" }), /did you mean poison/);
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison abc\n}\n", { name: "a" }), /attack_effect is invalid/);
});

test("attack_effect di luar blok attack dilewati dengan peringatan; attack tanpa == ditolak; user == attack berlaku untuk semua pukulan", async () => {
  const r = await HX.translate(SWORD + "if(pedang == right_click){\n attack_effect: poison\n}\n", { name: "a" });
  assert.ok(r.warnings.some((w) => /only works inside an attack block/.test(w))); assert.ok(!/hitEffect\(target/.test(jsOf(r)));
  await assert.rejects(HX.translate(SWORD + "if(pedang attack){\n attack_effect: poison\n}\n", { name: "a" }), /missing ==/);
  const r2 = await HX.translate(SWORD + "if(user == attack){\n attack_effect: weakness 3s\n}\n", { name: "a" });
  assert.match(jsOf(r2), /if \(\(true\)\)[\s\S]*hitEffect\(target, "weakness", 60\)/);
});

test("attack bersama left_click tetap bekerja dan skrip valid secara sintaks", async () => {
  const r = await HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison\n}\nif(pedang == left_click){\n spawn:zz\n}\n{mob\n name_tag:zz\n}\n", { name: "a" }), js = jsOf(r);
  assert.match(js, /onClick\(p, "left", id, target\)/);
  const tmp = join(mkdtempSync(join(tmpdir(), "hx-")), "m.mjs"); writeFileSync(tmp, js);
  execFileSync(process.execPath, ["--check", tmp]);
});

test("attack_effect level: level 2 menjadi amplifier 1, tanpa level tidak menambah argumen, batas 1 sampai 256", async () => {
  const r = await HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison 5s level 2\n attack_effect: weakness level 3\n attack_effect: wither 4s level 1\n attack_effect: slowness 2s\n}\n", { name: "a" }), js = jsOf(r);
  assert.match(js, /hitEffect\(target, "poison", 100, 1\);/);
  assert.match(js, /hitEffect\(target, "weakness", 200, 2\);/);
  assert.match(js, /hitEffect\(target, "wither", 80\);/);
  assert.match(js, /hitEffect\(target, "slowness", 40\);/);
  assert.match(js, /amplifier: amp/);
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison level 0\n}\n", { name: "a" }), /level must be 1 to 256/);
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison level 300\n}\n", { name: "a" }), /level must be 1 to 256/);
  await assert.rejects(HX.translate(SWORD + "if(pedang == attack){\n attack_effect: poison level\n}\n", { name: "a" }), /attack_effect is invalid/);
});

test("ikon item besar dikecilkan ke 32x32 agar item 3D di tangan tidak lag", async () => {
  const W = 512, px = new Uint8Array(W * W * 4);
  for (let y = 100; y < 400; y++) for (let x = 200; x < 300; x++) { const i = (y * W + x) * 4; px[i] = 200; px[i + 1] = 10; px[i + 2] = 10; px[i + 3] = 255; }
  const big = HX.pngEncode(W, W, px);
  const r = await HX.translate("{item\n name_tag:sabit\n icon_item://:2611190001\n}\n", { name: "i", fetchAsset: async () => big });
  const out = HX.pngRGBA(find(r, "i_RP/textures/items/sabit.png").data);
  assert.equal(out.w, 32); assert.equal(out.h, 32);
  assert.ok(out.px[(16 * 32 + 16) * 4] > 150 && out.px[(16 * 32 + 16) * 4 + 3] === 255, "isi gambar tetap ada");
  assert.equal(out.px[3], 0, "latar tetap transparan");
  assert.ok(r.warnings.some((w) => /shrunk to 32x32/.test(w)));
  const small = HX.pngSolid(16, 16, [5, 5, 5]);
  const r2 = await HX.translate("{item\n name_tag:kecil\n icon_item://:2611190002\n}\n", { name: "k", fetchAsset: async () => small });
  assert.deepEqual([...find(r2, "k_RP/textures/items/kecil.png").data], [...small]);
});

test("ikon besar yang tidak bisa dibaca sendiri dikecilkan lewat browser (resizePng); tanpa itu diberi peringatan", async () => {
  const bad = new Uint8Array(40); bad.set([0x89, 0x50, 0x4e, 0x47, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 4, 0, 0, 0, 4, 0, 8, 6, 0, 0, 1]);
  const small = HX.pngSolid(32, 32, [7, 7, 7]);
  const r = await HX.translate("{item\n name_tag:x1\n icon_item://:2611190003\n}\n", { name: "z", fetchAsset: async () => bad, resizePng: async (u, m) => { assert.equal(m, 32); return small; } });
  assert.deepEqual([...find(r, "z_RP/textures/items/x1.png").data], [...small]);
  const r2 = await HX.translate("{item\n name_tag:x1\n icon_item://:2611190003\n}\n", { name: "z", fetchAsset: async () => bad });
  assert.ok(r2.warnings.some((w) => /could not be shrunk/.test(w)));
});

test("semua format gambar (gif, bmp, webp, avif, svg, ico, tiff) diubah ke png lewat browser", async () => {
  const small = HX.pngSolid(16, 16, [3, 4, 5]);
  const fm = { gif: [0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 1, 0], bmp: [0x42, 0x4d, 1, 2, 3, 4, 5, 6], avif: [0, 0, 0, 0x1c, 0x66, 0x74, 0x79, 0x70], ico: [0, 0, 1, 0, 1, 0, 16, 16], tiff: [0x49, 0x49, 0x2a, 0, 8, 0, 0, 0], webp: [0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0], svg: [...new TextEncoder().encode("<svg xmlns='http://www.w3.org/2000/svg'></svg>")] };
  for (const [k, v] of Object.entries(fm)) {
    let called = 0;
    const r = await HX.translate("{item\n name_tag:g\n icon_item://:2611190009\n}\n", { name: "g", fetchAsset: async () => new Uint8Array(v), imageToPng: async () => { called++; return small; } });
    assert.equal(called, 1, k);
    assert.deepEqual([...find(r, "g_RP/textures/items/g.png").data], [...small], k);
    assert.ok(r.warnings.some((w) => /converted to png automatically/.test(w)), k);
  }
});

test("crafting: pola dipangkas, nama resmi (iron_ingot, obsidian, minecraft:) dan banyak posisi sekaligus", async () => {
  const r = await HX.translate("{item\n name_tag:kapak\n crafting:1, 2, 3, Obsidian\n crafting:5, minecraft:iron_ingot\n crafting:8, iron_ingot,\n}\n", { name: "c" });
  const f = J(r, "c_RP/../c_BP/recipes/kapak.json".replace("c_RP/../", ""))["minecraft:recipe_shaped"];
  assert.deepEqual(f.pattern, ["AAA", " B ", " B "]);
  assert.equal(f.key.A.item, "minecraft:obsidian"); assert.equal(f.key.B.item, "minecraft:iron_ingot");
  assert.deepEqual(f.unlock, [{ context: "AlwaysUnlocked" }]);
});

test("destroying: 4x4 pada item merusak area 4x4 sesuai sisi blok yang dipukul (simulasi skrip)", async () => {
  const r = await HX.translate("{item\n name_tag:kapak\n}\nif(kapak == attack){\n destroying: 4x4\n}\n", { name: "d" }), js = dec(find(r, "d_BP/scripts/main.js"));
  assert.deepEqual(JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(js)[1]).area, { "hx:kapak": [4, 4, 1] });
  assert.ok(!/function chain/.test(js), "tidak ada rantai kosong");
  const tmp = join(mkdtempSync(join(tmpdir(), "hx-")), "m.mjs"); writeFileSync(tmp, js); execFileSync(process.execPath, ["--check", tmp]);
  const run = (face, mode) => {
    const subs = {}, ticks = [], cmds = [];
    const mk = (n) => ({ subscribe: (f) => { (subs[n] ||= []).push(f); } });
    const p = { id: "p1", getComponent: () => ({ getEquipment: () => ({ typeId: "hx:kapak" }) }), getBlockFromViewDirection: () => ({ face, block: { location: { x: 10, y: 64, z: 10 } } }), getGameMode: () => mode || "survival" };
    const world = { afterEvents: new Proxy({}, { get: (_, n) => mk(n) }), getAllPlayers: () => [p] }, system = { runInterval: (f) => ticks.push(f), run() {} };
    const src = js.replace(/import \{[^}]*\} from "@minecraft\/server";/, "const { world, system, EquipmentSlot } = __m;");
    new Function("__m", src)({ world, system, EquipmentSlot: { Mainhand: "m" } });
    ticks.forEach((f) => f());
    const dimension = { getBlock: () => ({ typeId: "minecraft:stone" }), runCommand: (c) => cmds.push(c) };
    subs.playerBreakBlock.forEach((f) => f({ player: p, block: { location: { x: 10, y: 64, z: 10 } }, dimension }));
    return cmds;
  };
  const up = run("Up");
  assert.equal(up.length, 15); assert.ok(up.every((c) => / 64 /.test(c) && /air destroy$/.test(c)));
  assert.ok(up.some((c) => c.startsWith("setblock 9 64 9 ")) && up.some((c) => c.startsWith("setblock 12 64 12 ")) && !up.some((c) => c.startsWith("setblock 10 64 10 ")));
  const north = run("North"); assert.equal(north.length, 15); assert.ok(north.every((c) => / 10 air destroy$/.test(c)), "dinding: z tetap");
  assert.ok(north.some((c) => c.startsWith("setblock 9 63 10 ")) && north.some((c) => c.startsWith("setblock 12 66 10 ")));
  assert.ok(run("Up", "creative").every((c) => /air$/.test(c) && !/destroy/.test(c)));
  await assert.rejects(HX.translate("{item\n name_tag:k\n}\nif(k == attack){\n destroying: 20x4\n}\n", {}), /1 to 16/);
  await assert.rejects(HX.translate("{item\n name_tag:k\n}\nif(k == attack){\n destroying: besar\n}\n", {}), /destroying is invalid/);
  const w = await HX.translate("{item\n name_tag:k\n}\nif(user == on){\n destroying: 3x3\n}\n", { name: "w" });
  assert.ok(w.warnings.some((x) => /needs an item condition/.test(x)));
});

test("destroying bersama attack_effect: rantai attack tetap jalan tanpa pernyataan destroying", async () => {
  const r = await HX.translate("{item\n name_tag:kapak\n}\nif(kapak == attack){\n attack_effect: poison\n destroying: 2x2\n}\n", { name: "d" }), js = dec(find(r, "d_BP/scripts/main.js"));
  assert.match(js, /hitEffect\(target, "poison"/); assert.ok(!r.warnings.some((x) => /unrecognized statement/.test(x)));
});

test("{item block membuat blok custom: tekstur, material, lang, crafting, dan place_block", async () => {
  const red = HX.pngSolid(16, 16, [200, 20, 20]);
  const src = "{item_block\n name_tag:diamond_merah\n icon_item://:2611190010\n hardness:3\n light:7\n crafting:1, 2, 3, iron_ingot\n crafting:5, obsidian\n}\n\nif(diamond_merah == right_click){\n    place_block:diamond_merah\n}\n";
  const r = await HX.translate(src, { name: "b", fetchAsset: async () => red });
  const b = J(r, "b_BP/blocks/diamond_merah.json")["minecraft:block"];
  assert.equal(b.description.identifier, "hx:diamond_merah");
  assert.equal(b.components["minecraft:destructible_by_mining"].seconds_to_destroy, 3); assert.equal(b.components["minecraft:light_emission"], 7);
  assert.equal(b.components["minecraft:material_instances"]["*"].texture, "hx_diamond_merah");
  assert.deepEqual([...find(r, "b_RP/textures/blocks/diamond_merah.png").data], [...red]);
  assert.equal(J(r, "b_RP/textures/terrain_texture.json").texture_data.hx_diamond_merah.textures, "textures/blocks/diamond_merah");
  assert.ok(dec(find(r, "b_RP/texts/en_US.lang")).includes("tile.hx:diamond_merah.name=Diamond Merah"));
  const rc = J(r, "b_BP/recipes/diamond_merah.json")["minecraft:recipe_shaped"];
  assert.deepEqual(rc.pattern, ["AAA", " B "]); assert.equal(rc.result.item, "hx:diamond_merah");
  const js = dec(find(r, "b_BP/scripts/main.js"));
  assert.match(js, /click === "right" && id === "hx:diamond_merah"/); assert.match(js, /placeBlock\(p, "hx:diamond_merah"\)/);
  const tmp = join(mkdtempSync(join(tmpdir(), "hx-")), "m.mjs"); writeFileSync(tmp, js); execFileSync(process.execPath, ["--check", tmp]);
  assert.equal(r.summary.items >= 0, true);
  const r2 = await HX.translate("{item_block\n name_tag:batu\n}\n", { name: "q" });
  assert.ok(find(r2, "q_BP/blocks/batu.json") && r2.warnings.some((w) => /no png texture/.test(w)));
  const r3 = await HX.translate("{item\n name_tag:x\n}\nif(x == right_click){\n place_block:nope\n}\n", { name: "z" });
  assert.ok(r3.warnings.some((w) => /not declared with \{item block/.test(w)));
});

test("spasi tidak diterima: {item block, right click, dan nama bahan crafting harus pakai _", async () => {
  await assert.rejects(HX.translate("{item block\n name_tag:a\n}\n", {}), /underscore/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n}\nif(a == right click){\n spawn:a\n}\n", {}), /right_click with an underscore/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n crafting:1, iron ingot\n}\n", {}), /use _ instead of a space/);
});

const MENU = '{menu\ndisplay:invisible\nname_tag:menu_pilihan\nradius:25x25 px\nbackground:red\nbutton_place:x(6) y(7) "klik saya"\nbutton_place:x(2) y(1) "pertama"\n}\n\nif(menu_pilihan == click_e === button_x(5)_Y(5)"menu"){\n    display:blok\n}else{\n    display:invisible\n}\n\nif(klik saya == click){\n    menu_pilihan: invisible\n}\n';
test("{menu: form bawaan, launcher, urutan tombol dari x/y, if/else display, klik tombol", async () => {
  const r = await HX.translate(MENU, { name: "m" });
  const js = dec(find(r, "m_BP/scripts/main.js")), tmp = join(mkdtempSync(join(tmpdir(), "hx-")), "m.mjs"); writeFileSync(tmp, js); execFileSync(process.execPath, ["--check", tmp]);
  const cfg = JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(js)[1]).menus.menu_pilihan;
  assert.deepEqual(cfg.buttons.map((b) => b.label), ["pertama", "klik saya"]);
  assert.equal(cfg.show, false); assert.equal(cfg.launcher, "hx:menu_pilihan_menu"); assert.equal(cfg.handled, true);
  assert.match(js, /blk === "open:menu_pilihan"/); assert.match(js, /blk === "btn:menu_pilihan:klik saya"/);
  assert.match(js, /menuDisplay\(p, "menu_pilihan", true\)/); assert.match(js, /menuDisplay\(p, "menu_pilihan", false\)/);
  assert.ok(find(r, "m_BP/items/menu_pilihan_menu.json"));
  assert.ok(dec(find(r, "m_BP/manifest.json")).includes("@minecraft/server-ui"));
  assert.ok(dec(find(r, "m_RP/texts/en_US.lang")).includes("item.hx:menu_pilihan_menu=menu"));
  assert.ok(r.warnings.some((x) => /radius is ignored/.test(x)));
  // simulasi: spawn -> launcher diberikan; klik launcher -> form tampil; pilih tombol -> menu tertutup
  const subs = {}, mk = (n) => ({ subscribe: (f) => { (subs[n] ||= []).push(f); } }), given = [], shown = [], timeouts = [];
  const p = { id: "p1", runCommand: (c) => given.push(c), getComponent: () => ({ container: { size: 1, getItem: () => null } }) };
  const world = { afterEvents: new Proxy({}, { get: (_, n) => mk(n) }), getAllPlayers: () => [p] };
  const system = { run: (f) => f(), runTimeout: (f) => timeouts.push(f), runInterval() {} };
  class AFD { title(t) { this.t = t; return this; } button(b) { (this.b ||= []).push(b); return this; } show() { shown.push(this); return Promise.resolve({ canceled: false, selection: 1 }); } }
  const src = js.replace(/import \{[^}]*\} from "@minecraft\/server";/, "const { world, system, EquipmentSlot } = __m;").replace(/import \{[^}]*\} from "@minecraft\/server-ui";/, "const { ActionFormData } = __u;");
  new Function("__m", "__u", src)({ world, system, EquipmentSlot: {} }, { ActionFormData: AFD });
  subs.playerSpawn.forEach((f) => f({ player: p, initialSpawn: true })); timeouts.splice(0).forEach((f) => f());
  assert.ok(given.some((c) => c === "give @s hx:menu_pilihan_menu 1")); assert.equal(shown.length, 0, "display:invisible: tidak terbuka otomatis");
  subs.itemUse.forEach((f) => f({ source: p, itemStack: { typeId: "hx:menu_pilihan_menu" } }));
  assert.equal(shown.length, 1); assert.deepEqual(shown[0].b, ["pertama", "klik saya"]);
  await new Promise((r) => setTimeout(r, 5));
  subs.itemUse.forEach((f) => f({ source: p, itemStack: { typeId: "hx:menu_pilihan_menu" } }));
  assert.equal(shown.length, 2, "setelah memilih tombol menu tertutup lalu bisa dibuka lagi");
});
test("{menu display:blok terbuka otomatis saat masuk; menu tanpa kondisi dibuka lewat launcher bawaan tidak ada; kesalahan penulisan ditolak", async () => {
  const r = await HX.translate('{menu\nname_tag:awal\ndisplay:blok\nbutton_place:x(1) y(1) "ok"\n}\n', { name: "a" });
  assert.equal(JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(dec(find(r, "a_BP/scripts/main.js")))[1]).menus.awal.show, true);
  await assert.rejects(HX.translate('{menu\nname_tag:a\nbutton_place:6,7 "x"\n}\n', {}), /button_place is invalid/);
  await assert.rejects(HX.translate('{menu\nname_tag:a\ndisplay:aneh\n}\n', {}), /display must be/);
});

test("class item: level, Buku Sihir, dan skrip upgrade", async () => {
  const r = await HX.translate("{item\n name_tag:pedang_naga\n class:sword\n max_level:3\n}\n{item\n name_tag:beliung\n class:pickaxe\n}\n{item\n name_tag:baju\n class:armor\n armor_slot:helmet\n max_level:2\n}\nif(pedang_naga == attack){\n attack_effect: poison 5s\n}\n", { name: "k" });
  const it = (n) => J(r, "k_BP/items/" + n + ".json")["minecraft:item"];
  assert.equal(it("pedang_naga").components["minecraft:damage"], 5);
  assert.equal(it("pedang_naga_lv3").components["minecraft:damage"], 7);
  assert.equal(it("pedang_naga_lv3").description.menu_category.category, "none");
  assert.equal(it("pedang_naga_lv2").components["minecraft:glint"], true);
  assert.ok(it("beliung").components["minecraft:digger"]);
  assert.equal(it("beliung").components["minecraft:enchantable"].slot, "pickaxe");
  assert.equal(it("baju").components["minecraft:wearable"].slot, "slot.armor.head");
  assert.equal(it("baju").components["minecraft:wearable"].protection, 2);
  assert.equal(it("baju_lv2").components["minecraft:wearable"].protection, 3);
  assert.ok(!find(r, "k_BP/items/baju_lv3.json"));
  assert.ok(find(r, "k_BP/items/buku_sihir.json") && find(r, "k_BP/recipes/buku_sihir.json"));
  const js = dec(find(r, "k_BP/scripts/main.js"));
  assert.match(js, /ItemStack/);
  assert.match(js, /server-ui/);
  assert.match(js, /bid\(it \? it\.typeId/);
  assert.match(dec(find(r, "k_RP/texts/en_US.lang")), /item\.hx:pedang_naga_lv2=Pedang Naga Lv\.2/);
  assert.doesNotThrow(() => new vm.Script(js.replace(/^import .*$/gm, "")));
  assert.match(dec(find(r, "k_BP/manifest.json")), /server-ui/);
});

test("class item: galat dan kasus tepi", async () => {
  await assert.rejects(HX.translate("{item\n name_tag:a\n class:pisau\n}\n", {}), /not a known class/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n class:armor\n armor_slot:topi\n}\n", {}), /armor_slot must be/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n class:sword\n max_level:11\n}\n", {}), /max_level/);
  await assert.rejects(HX.translate("{item\n name_tag:a\n class:sword\n}\n{item\n name_tag:a_lv2\n}\n", {}), /reserved/);
  const r = await HX.translate("{item\n name_tag:topi\n class:helmet\n max_level:1\n}\n", { name: "k" });
  assert.equal(J(r, "k_BP/items/topi.json")["minecraft:item"].components["minecraft:wearable"].slot, "slot.armor.head");
  assert.ok(!find(r, "k_BP/items/topi_lv2.json"));
  const n = await HX.translate("{item\n name_tag:biasa\n}\n", { name: "k" });
  assert.ok(!find(n, "k_BP/items/buku_sihir.json"));
});

test("{command}: perintah chat dengan out#", async () => {
  const src = '{command\n    command:/start\n    command:/skor\n}\n\nif(word == /skor){\n    out#"skor:";\n    out#"Andi: 56";\n}\n';
  const r = await HX.translate(src, { name: "c" });
  const js = dec(find(r, "c_BP/scripts/main.js"));
  assert.deepEqual(JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(js)[1]).cmds, ["/start", "/skor"]);
  assert.match(js, /say\(p, "skor:"\);/);
  assert.match(js, /say\(p, "Andi: 56"\);/);
  assert.match(js, /word === "\/skor"/);
  assert.ok(r.warnings.some((w) => /\/start has no if/.test(w.message || w)));
  // jalankan skrip dengan Minecraft palsu: ketik "skor" -> pesan keluar di chat
  const sent = [], subs = {};
  const world = { beforeEvents: { chatSend: { subscribe: (f) => (subs.chat = f) } }, afterEvents: new Proxy({}, { get: () => ({ subscribe() {} }) }), getAllPlayers: () => [], getDynamicProperty: () => undefined, setDynamicProperty() {} };
  const system = { run: (f) => f(), runInterval() {}, runTimeout() {}, beforeEvents: {} };
  const code = js.replace(/^import .*$/gm, "");
  new Function("world", "system", "EquipmentSlot", code)(world, system, {});
  const ev = { message: "!Skor", sender: { sendMessage: (t) => sent.push(t) }, cancel: false };
  subs.chat(ev);
  assert.equal(ev.cancel, true);
  assert.deepEqual(sent, ["skor:", "Andi: 56"]);
  const ev2 = { message: "halo", sender: { sendMessage: (t) => sent.push(t) }, cancel: false };
  subs.chat(ev2); assert.equal(ev2.cancel, false);
  await assert.rejects(HX.translate('{command\n command:skor\n}\n', {}), /must start with \//);
  await assert.rejects(HX.translate('{command\n command:/a\n}\nif(word == /a){\n out#skor\n}\n', {}), /double quotes/);
  await assert.rejects(HX.translate('{command\n command:/a\n command:/a\n}\n', {}), /twice/);
});

// ---- variabel: int, double, auto ----
async function runChat(srcHx, words) {
  const r = await HX.translate(srcHx, { name: "v" });
  const js = dec(find(r, "v_BP/scripts/main.js"));
  const sent = [], subs = {}, store = {};
  const world = { beforeEvents: { chatSend: { subscribe: (f) => (subs.chat = f) } }, afterEvents: new Proxy({}, { get: () => ({ subscribe() {} }) }), getAllPlayers: () => [], getDynamicProperty: (k) => store[k], setDynamicProperty: (k, v) => (store[k] = v) };
  const system = { run: (f) => f(), runInterval() {}, runTimeout() {}, beforeEvents: {} };
  new Function("world", "system", "EquipmentSlot", js.replace(/^import .*$/gm, ""))(world, system, {});
  for (const w of words) subs.chat({ message: w, sender: { sendMessage: (t) => sent.push(t) }, cancel: false });
  return { sent, js, store, r };
}
const VH = (body) => '{command\n    command:/a\n    command:/b\n}\n' + body;

test("variabel: int global, out# dengan +, += dan -=", async () => {
  const { sent, store } = await runChat(VH('int point = 67\nif(word == /a){\n    out#"point: " + point;\n    point += 3\n    out#"sekarang: " + point;\n}\nif(word == /b){\n    point -= 10\n    out#point;\n}\n'), ["a", "b", "a"]);
  assert.deepEqual(sent, ["point: 67", "sekarang: 70", "60", "point: 60", "sekarang: 63"]);
  assert.match(store.hx_vars, /"point":\[67,63\]/);
});

test("variabel: double, auto, lokal, *= /= ++", async () => {
  const src = VH('double speed = 1.5\nauto nama = "Andi"\nif(word == /a){\n    speed += 0.25\n    speed *= 2\n    out#"speed: " + speed;\n    nama += "!"\n    out#nama;\n    int lokal = 5\n    lokal++\n    lokal /= 4\n    out#"lokal: " + lokal;\n}\n');
  const { sent } = await runChat(src, ["a", "a"]);
  assert.deepEqual(sent, ["speed: 3.5", "Andi!", "lokal: 1", "speed: 7.5", "Andi!!", "lokal: 1"]);
});

test("variabel: auto menyesuaikan nilai, batas digit int 14 dan double 15", async () => {
  const { sent } = await runChat(VH('auto x = 5\nint big = 99999999999999\ndouble d = 0.1\nif(word == /a){\n    x += 1.5\n    out#x;\n    big += 100\n    out#big;\n    d += 0.2\n    out#d;\n}\n'), ["a"]);
  assert.deepEqual(sent, ["6.5", "99999999999999", "0.3"]);
});

test("variabel: galat penulisan", async () => {
  await assert.rejects(HX.translate(VH('int a = 1.5\n'), {}), /int cannot hold the decimal/);
  await assert.rejects(HX.translate(VH('int a = 123456789012345\n'), {}), /14 digits/);
  await assert.rejects(HX.translate(VH('double a = 1234567890123456\n'), {}), /digits/);
  await assert.rejects(HX.translate(VH('int a = "x"\n'), {}), /cannot hold text/);
  await assert.rejects(HX.translate(VH('int a\n'), {}), /initial value is required/);
  await assert.rejects(HX.translate(VH('int a = 1\nint a = 2\n'), {}), /declared twice/);
  await assert.rejects(HX.translate(VH('if(word == /a){\n  zzz += 1\n}\n'), {}), /not declared/);
  await assert.rejects(HX.translate(VH('if(word == /a){\n  out#skor\n}\n'), {}), /double quotes/);
  await assert.rejects(HX.translate(VH('auto t = "a"\nif(word == /a){\n  t -= 1\n}\n'), {}), /only work on numbers|numbers/);
});

test("out# di luar {command tetap punya say()", async () => {
  const r = await HX.translate('{item\n    name_tag:p\n}\nif(p == right_click){\n    out#"hai";\n}\n', { name: "o" });
  assert.match(dec(find(r, "o_BP/scripts/main.js")), /function say\(p, t\)/);
});

// ---- tekstur blok vanilla: {obsidian models://:ID } ----
test("blok vanilla: {obsidian menimpa textures/blocks/obsidian.png", async () => {
  const tex = HX.pngSolid(16, 16, [40, 200, 220]);
  const r = await HX.translate("{obsidian\n    models://:2611210002\n}\n", { name: "t", fetchAsset: async (id) => (id === "2611210002" ? tex : null) });
  const f = find(r, "t_RP/textures/blocks/obsidian.png");
  assert.ok(f, "berkas tekstur obsidian harus ada di Resource Pack");
  assert.deepEqual([...f.data], [...tex]);
  assert.ok(!find(r, "t_RP/textures/terrain_texture.json"), "menimpa blok vanilla tidak butuh terrain_texture.json");
  assert.ok(find(r, "t_RP/manifest.json"));
});

test("blok vanilla: satu gambar untuk beberapa berkas, ditimpa bersama item_block", async () => {
  const tex = HX.pngSolid(16, 16, [200, 30, 30]);
  const r = await HX.translate("{tnt\n    models://:2611210003\n}\n{item_block\n    name_tag:merah\n    icon_item://:2611210003\n}\n", { name: "t", fetchAsset: async () => tex });
  for (const n of ["tnt_side", "tnt_top", "tnt_bottom"]) assert.ok(find(r, "t_RP/textures/blocks/" + n + ".png"), n);
  assert.ok(find(r, "t_RP/textures/terrain_texture.json"), "item_block tetap membuat terrain_texture.json");
});

test("blok vanilla: tanpa gambar hanya peringatan, nama tidak dikenal ditolak, ganda ditolak", async () => {
  const r = await HX.translate("{obsidian\n    models://:2611210009\n}\n", { name: "t", fetchAsset: async () => null });
  assert.ok(!find(r, "t_RP/textures/blocks/obsidian.png"));
  assert.ok(r.warnings.some((w) => /vanilla texture was kept/.test(w)));
  await assert.rejects(HX.translate("{batu_aneh\n    models://:2611210009\n}\n", {}), /unknown declaration category/);
  await assert.rejects(HX.translate("{obsidian\n    models://:2611210009\n}\n{obsidian\n    models://:2611210009\n}\n", {}), /declared twice/);
});

test("{block + item_drop: blok custom menjatuhkan item lewat loot table", async () => {
  const red = HX.pngSolid(16, 16, [200, 20, 20]);
  const src = "{block\n    name_tag:diamond_merah\n    models://:2611210001\n}\n\n{item\n    name_tag:diamond_merah_ingot\n    icon_item://:2611210002\n}\n\nif(diamond_merah == destroy){\n    item_drop:diamond_merah_ingot 2-4\n    item_drop:iron_ingot\n}\n";
  const r = await HX.translate(src, { name: "d", fetchAsset: async () => red });
  const b = J(r, "d_BP/blocks/diamond_merah.json")["minecraft:block"];
  assert.equal(b.description.identifier, "hx:diamond_merah");
  assert.equal(b.components["minecraft:loot"], "loot_tables/blocks/diamond_merah.json");
  const lt = J(r, "d_BP/loot_tables/blocks/diamond_merah.json");
  assert.equal(lt.pools.length, 2);
  assert.equal(lt.pools[0].entries[0].name, "hx:diamond_merah_ingot");
  assert.deepEqual(lt.pools[0].entries[0].functions[0].count, { min: 2, max: 4 });
  assert.equal(lt.pools[1].entries[0].name, "minecraft:iron_ingot"); assert.equal(lt.pools[1].entries[0].functions[0].count, 1);
  assert.equal(r.warnings.filter((w) => /item_drop|not recognized/.test(w)).length, 0);
  const r2 = await HX.translate("{block\n name_tag:batu\n}\n", { name: "q" });
  assert.ok(find(r2, "q_BP/blocks/batu.json") && !find(r2, "q_BP/loot_tables/blocks/batu.json"), "tanpa item_drop tidak ada loot table");
  await assert.rejects(HX.translate(src.replace("if(diamond_merah", "if(dimond_merah"), { name: "e", fetchAsset: async () => red }), /not a declared \{block/);
  await assert.rejects(HX.translate(src.replace("2-4", "9-2"), { name: "e", fetchAsset: async () => red }), /amount must be 1 to 64/);
  await assert.rejects(HX.translate(src.replace("== destroy", "== right_click"), { name: "e", fetchAsset: async () => red }), /no == destroy/);
  const r3 = await HX.translate(src.replace("item_drop:diamond_merah_ingot 2-4", "item_drop:diamond_merah_ingott"), { name: "w", fetchAsset: async () => red });
  assert.ok(r3.warnings.some((w) => /Did you mean "diamond_merah_ingot"/.test(w)));
});

test("{food: makanan memakai minecraft:food (animasi makan bawaan), tanpa script dan tanpa if", async () => {
  const red = HX.pngSolid(16, 16, [200, 20, 20]);
  const r = await HX.translate("{food\n    name_tag:super_food\n    saturation:+2\n    icon_item://:2611210005\n}\n", { name: "f", fetchAsset: async () => red });
  const it = J(r, "f_BP/items/super_food.json")["minecraft:item"];
  assert.equal(it.description.identifier, "hx:super_food");
  assert.equal(it.components["minecraft:food"].nutrition, 2);
  assert.equal(it.components["minecraft:use_modifiers"].use_duration, 1.6);
  assert.equal(it.components["minecraft:icon"].textures.default, "super_food");
  assert.equal(it.components["minecraft:hand_equipped"], undefined);
  assert.ok(!find(r, "f_BP/scripts/main.js"), "makanan murni data, tanpa script");
  assert.ok(dec(find(r, "f_RP/texts/en_US.lang")).includes("item.hx:super_food=Super Food"));
  const r2 = await HX.translate("{food\n name_tag:roti\n}\n", { name: "g" });
  assert.equal(J(r2, "g_BP/items/roti.json")["minecraft:item"].components["minecraft:food"].nutrition, 2);
  assert.ok(r2.warnings.some((w) => /no saturation/.test(w)));
  await assert.rejects(HX.translate("{food\n name_tag:x\n saturation:+25\n}\n", {}), /1 to 20/);
  await assert.rejects(HX.translate("{food\n name_tag:x\n saturation:banyak\n}\n", {}), /invalid/);
  const r3 = await HX.translate("{food\n name_tag:daging\n saturation:+6\n}\n{block\n name_tag:peti\n}\nif(peti == destroy){\n item_drop:daging 2\n}\n", { name: "h" });
  assert.equal(J(r3, "h_BP/loot_tables/blocks/peti.json").pools[0].entries[0].name, "hx:daging");
});

/* ---------- V94: bom nuclier (if(flint_and_steel == nuclier){ wait / boom / radius }) ---------- */
const NUKE_SRC = (body) => "{block\n    name_tag:nuclier\n    models://:2611210003\n}\n\nif(flint_and_steel == nuclier){\n" + body + "\n}\n";
const nukeTex = HX.pngSolid(16, 16, [20, 160, 40]);
const nukeRun = async (body, name) => HX.translate(NUKE_SRC(body), { name: name || "n", fetchAsset: async () => nukeTex });
const nukeJs = (r, n) => dec(find(r, (n || "n") + "_BP/scripts/main.js"));

test("bom nuclier: konfigurasi, entitas berkedip (BP + RP), tekstur putih, tanpa peringatan", async () => {
  const r = await nukeRun("    wait:6 second\n    boom:on\n    radius:3x3x3");
  const js = nukeJs(r);
  assert.deepEqual(JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(js)[1]).nuke, [{ item: "minecraft:flint_and_steel", block: "hx:nuclier", wait: 6, boom: true, size: [3, 3, 3] }]);
  assert.ok(!/function chain/.test(js), "tidak ada rantai kosong");
  const tmp = join(mkdtempSync(join(tmpdir(), "hx-")), "m.mjs"); writeFileSync(tmp, js); execFileSync(process.execPath, ["--check", tmp]);
  assert.equal(r.warnings.filter((w) => /nuclier|ignite|unrecognized/.test(w)).length, 0);
  const bp = J(r, "n_BP/entities/hx_nuclier_primed.json")["minecraft:entity"];
  assert.equal(bp.description.identifier, "hx:nuclier_primed"); assert.equal(bp.components["minecraft:timer"].time, 16);
  assert.ok(bp.component_groups["hx:expire"]["minecraft:instant_despawn"]);
  const cl = J(r, "n_RP/entity/hx_nuclier_primed.entity.json")["minecraft:client_entity"].description;
  assert.equal(cl.identifier, "hx:nuclier_primed"); assert.deepEqual(cl.scripts.animate, ["blink"]);
  const an = J(r, "n_RP/animations/hx_nuclier_primed.animation.json").animations["animation.hx_nuclier_primed.blink"];
  assert.equal(an.animation_length, 0.5); assert.deepEqual(Object.keys(an.timeline), ["0.0", "0.25"]);
  assert.match(JSON.stringify(J(r, "n_RP/render_controllers/hx_nuclier_primed.render_controllers.json")), /variable\.flash/);
  const g = J(r, "n_RP/models/entity/hx_nuclier_primed.geo.json")["minecraft:geometry"][0];
  assert.equal(g.bones[0].cubes[0].uv.north.uv_size[0], 16);
  const flash = HX.pngRGBA(find(r, "n_RP/textures/entity/hx_nuclier_primed_flash.png").data), norm = HX.pngRGBA(find(r, "n_RP/textures/entity/hx_nuclier_primed.png").data);
  assert.ok(flash.px[0] > norm.px[0] + 100 && flash.px[1] > 200, "versi kilat jauh lebih putih");
  assert.ok(find(r, "n_RP/texts/en_US.lang") && /entity\.hx:nuclier_primed\.name=Primed Nuclier/.test(dec(find(r, "n_RP/texts/en_US.lang"))));
});

test("bom nuclier: bawaan wait 4 detik, radius 3x3x3; radius angka tunggal, dua angka, dan batas 5000", async () => {
  const get = async (b) => JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(nukeJs(await nukeRun(b))) [1]).nuke[0];
  assert.deepEqual(await get("    boom:on"), { item: "minecraft:flint_and_steel", block: "hx:nuclier", wait: 4, boom: true, size: [3, 3, 3] });
  assert.deepEqual((await get("    boom:on\n    radius:10")).size, [10, 10, 10]);
  assert.deepEqual((await get("    boom:on\n    radius:5000x5000")).size, [5000, 5000, 5000]);
  assert.deepEqual((await get("    boom:on\n    radius:20x6")).size, [20, 6, 6]);
  assert.deepEqual((await get("    boom:on\n    radius:5000x300x5000")).size, [5000, 300, 5000]);
  assert.equal((await get("    wait:1.5s\n    boom:on")).wait, 1.5);
  assert.equal((await get("    boom:off")).boom, false);
  await assert.rejects(nukeRun("    boom:on\n    radius:5001x5001"), /1 to 5000/);
  await assert.rejects(nukeRun("    boom:on\n    radius:0"), /1 to 5000/);
  await assert.rejects(nukeRun("    boom:on\n    radius:besar"), /radius is invalid/);
  await assert.rejects(nukeRun("    wait:601 second\n    boom:on"), /0 to 600/);
  await assert.rejects(nukeRun("    wait:2 minutes\n    boom:on"), /seconds only/);
  await assert.rejects(nukeRun("    wait:lama\n    boom:on"), /wait is invalid/);
  await assert.rejects(nukeRun("    boom:ya"), /boom:on or boom:off/);
  const w = await nukeRun("    wait:2 second\n    radius:3x3x3");
  assert.ok(w.warnings.some((x) => /no boom:on/.test(x)));
  const w2 = await nukeRun("    boom:on\n    spawn:monster");
  assert.ok(w2.warnings.some((x) => /unrecognized statement inside a block-ignite/.test(x)));
});

test("bom nuclier: nama item harus resmi bahasa Inggris (korek ditolak), blok harus dideklarasikan", async () => {
  await assert.rejects(HX.translate(NUKE_SRC("    boom:on").replace("flint_and_steel", "korek"), { fetchAsset: async () => nukeTex }), /not an official Minecraft Bedrock item name[\s\S]*flint_and_steel/);
  await assert.rejects(HX.translate(NUKE_SRC("    boom:on").replace("flint_and_steel", "user"), { fetchAsset: async () => nukeTex }), /needs an item/);
  const r = await HX.translate("{block\n name_tag:peti\n}\nif(flint_and_steel == nuclier){\n boom:on\n}\n", { name: "q" });
  assert.ok(r.warnings.some((x) => /unrecognized condition, skipped: "flint_and_steel == nuclier"/.test(x)));
  assert.ok(!find(r, "q_BP/entities/hx_nuclier_primed.json"));
  await assert.rejects(HX.translate(NUKE_SRC("    boom:on") + "{block\n name_tag:nuclier_primed\n}\n", {}), /reserved for the primed/);
  const c = await HX.translate("{item\n name_tag:korek_saya\n}\n" + NUKE_SRC("    boom:on").replace("flint_and_steel", "korek_saya"), { name: "c", fetchAsset: async () => nukeTex });
  assert.equal(JSON.parse(/const CFG = (\{[\s\S]*?\n\});/.exec(nukeJs(c, "c"))[1]).nuke[0].item, "hx:korek_saya");
});

// simulasi skrip: nyalakan -> entitas muncul -> hitung mundur -> ledakan -> area dihapus bertahap
function nukeSandbox(js, { before = true, loaded = () => true, held = "minecraft:flint_and_steel", mode = "survival" } = {}) {
  const subs = {}, ticks = [], runs = [], timeouts = [], cmds = [], spawned = [], booms = [], msgs = [], removed = [];
  const mk = (n) => ({ subscribe: (f) => { (subs[n] ||= []).push(f); } });
  const dur = { damage: 0, maxDurability: 65 };
  const item = { typeId: held, amount: 1, getComponent: (c) => (c === "durability" ? dur : undefined) };
  let hand = item;
  const p = { id: "p1", getGameMode: () => mode, runCommand: (c) => cmds.push("P:" + c), sendMessage: (m) => msgs.push(m), onScreenDisplay: { setActionBar() {} }, getComponent: () => ({ getEquipment: () => hand, setEquipment: (s, v) => { hand = v; } }) };
  const target = { typeId: "hx:nuclier", location: { x: 10, y: 64, z: 10 } }, blocks = new Map([["10,64,10", target]]);
  const dim = {
    id: "minecraft:overworld", heightRange: { min: -64, max: 320 },
    getBlock: (l) => { const b = blocks.get(l.x + "," + l.y + "," + l.z); if (b) return b; if (!loaded(l)) throw new Error("unloaded"); return { typeId: "minecraft:stone", setType() {} }; },
    spawnEntity: (id, at) => { const e = { isValid: true, location: at, remove() { this.isValid = false; removed.push(id); } }; spawned.push({ id, at }); return e; },
    createExplosion: (at, power, o) => booms.push({ at, power, o }), runCommand: (c) => { cmds.push(c); return { successCount: 1 }; },
  };
  target.dimension = dim; target.setType = (t) => { target.typeId = t; };
  const world = { afterEvents: new Proxy({}, { get: (_, n) => mk("a_" + n) }), getAllPlayers: () => [p] };
  world.beforeEvents = before ? new Proxy({}, { get: (_, n) => mk("b_" + n) }) : undefined;
  const system = { run: (f) => runs.push(f), runTimeout: (f, t) => timeouts.push({ f, t }), runInterval: (f) => ticks.push(f) };
  const src = js.replace(/import \{[^}]*\} from "@minecraft\/server";/, "const { world, system, EquipmentSlot } = __m;");
  new Function("__m", src)({ world, system, EquipmentSlot: { Mainhand: "m" } });
  const ignite = () => { const ev = { itemStack: item, block: target, blockFace: "Up", source: p, cancel: false }; (subs[before ? "b_itemUseOn" : "a_itemUseOn"] || []).forEach((f) => f(ev)); return ev; };
  const flush = () => { while (runs.length) runs.shift()(); };
  return { subs, ticks, timeouts, cmds, spawned, booms, msgs, removed, target, dur, p, dim, ignite, flush, hand: () => hand, tickAll: (n) => { for (let i = 0; i < n; i++) ticks.forEach((f) => f()); } };
}

test("bom nuclier (simulasi): dinyalakan korek -> berkedip 6 detik -> meledak 3x3x3, korek berkurang", async () => {
  const js = nukeJs(await nukeRun("    wait:6 second\n    boom:on\n    radius:3x3x3"));
  const s = nukeSandbox(js);
  const ev = s.ignite(); assert.equal(ev.cancel, true, "api asli korek (membuat api) dibatalkan");
  s.ignite(); // klik ganda di tick yang sama tidak boleh menyalakan dua kali
  s.flush();
  assert.equal(s.target.typeId, "minecraft:air", "blok berubah menjadi bom");
  assert.deepEqual(s.spawned, [{ id: "hx:nuclier_primed", at: { x: 10.5, y: 64, z: 10.5 } }]);
  assert.ok(s.cmds.some((c) => /^playsound random\.fuse/.test(c)));
  assert.equal(s.dur.damage, 1, "durability korek berkurang 1 di survival");
  assert.equal(s.timeouts.length, 1); assert.equal(s.timeouts[0].t, 120, "6 detik = 120 tick");
  assert.equal(s.booms.length, 0, "belum meledak sebelum hitung mundur selesai");
  s.timeouts[0].f();
  assert.deepEqual(s.removed, ["hx:nuclier_primed"]);
  assert.equal(s.booms.length, 1); assert.equal(s.booms[0].o.breaksBlocks, false);
  s.tickAll(3);
  assert.deepEqual(s.cmds.filter((c) => /^fill/.test(c)), ["fill 9 63 9 11 65 11 air destroy"]);
  assert.equal(s.msgs.length, 0, "area kecil tidak mengirim pesan");
  // menyalakan lagi di blok yang sudah hilang tidak melakukan apa-apa
  s.ignite(); s.flush(); assert.equal(s.spawned.length, 1);
});

test("bom nuclier (simulasi): creative tidak mengurangi korek; tanpa boom:on tidak meledak; fallback afterEvents menghapus api", async () => {
  const s = nukeSandbox(nukeJs(await nukeRun("    wait:2 second\n    boom:on")), { mode: "creative" });
  s.ignite(); s.flush(); assert.equal(s.dur.damage, 0);
  const off = nukeSandbox(nukeJs(await nukeRun("    wait:2 second\n    boom:off")));
  off.ignite(); off.flush(); off.timeouts[0].f(); off.tickAll(3);
  assert.equal(off.booms.length, 0); assert.ok(!off.cmds.some((c) => /^fill/.test(c))); assert.deepEqual(off.removed, ["hx:nuclier_primed"]);
  const fb = nukeSandbox(nukeJs(await nukeRun("    boom:on")), { before: false });
  const fire = { typeId: "minecraft:fire", setType(t) { this.typeId = t; } };
  const orig = fb.dim.getBlock; fb.dim.getBlock = (l) => (l.x === 10 && l.y === 65 && l.z === 10 ? fire : orig(l));
  const ev = fb.ignite(); assert.equal(ev.cancel, false); fb.flush();
  assert.equal(fire.typeId, "minecraft:air", "api yang dibuat korek di sisi atas dihapus");
  const other = nukeSandbox(nukeJs(await nukeRun("    boom:on")), { held: "minecraft:stick" });
  other.ignite(); other.flush(); assert.equal(other.spawned.length, 0, "item lain tidak menyalakan");
});

test("bom nuclier (simulasi): radius 5000x5000 dikerjakan bertahap per chunk, hanya chunk termuat, bedrock aman", async () => {
  const js = nukeJs(await nukeRun("    wait:0 second\n    boom:on\n    radius:5000x5000"));
  const s = nukeSandbox(js, { loaded: (l) => Math.abs(Math.floor(l.x / 16) - 0) <= 3 && Math.abs(Math.floor(l.z / 16) - 0) <= 3 });
  s.ignite(); s.flush(); s.timeouts[0].f();
  let guard = 0; while (!s.msgs.length && guard++ < 5000) s.tickAll(1);
  assert.ok(s.msgs.length === 1, "pesan ringkasan setelah selesai");
  assert.match(s.msgs[0], /Nuclier: 49 of \d+ chunks cleared \(\d+ not loaded, skipped\)/);
  const fills = s.cmds.filter((c) => /^fill/.test(c)).map((c) => c.split(" ").slice(1, 7).map(Number));
  assert.ok(fills.length >= 49 * 3, "tiap chunk termuat dihapus lewat fill (maks 32768 blok per perintah)");
  assert.ok(fills.every((f) => f[1] >= -59 && f[4] <= 319), "lapisan bedrock paling bawah tidak disentuh");
  assert.ok(fills.every((f) => (f[3] - f[0] + 1) * (f[4] - f[1] + 1) * (f[5] - f[2] + 1) <= 32768));
  assert.ok(!s.cmds.some((c) => /destroy/.test(c)), "area besar tanpa drop item");
  assert.ok(fills.length < 600, "chunk yang tidak termuat dilewati tanpa perintah fill");
  const near = fills[0]; assert.ok(near[0] >= -16 && near[0] <= 16, "mulai dari pusat ledakan");
});

/* ---------- random_block: blok ore muncul di kedalaman apa pun ---------- */
test("random_block:-15 ({Block huruf besar): ore di seluruh kedalaman -64..320, puncak di -15", async () => {
  const r = await HX.translate("{Block\n    name_tag:ore\n    random_block:-15\n}\n", { name: "ore.hx" });
  const BPF = (p) => r.files.find((f) => f.path.endsWith(p));
  const feat = JSON.parse(dec(BPF("features/ore_ore.json")));
  assert.equal(feat["minecraft:ore_feature"].replace_rules[0].places_block, "hx:ore");
  assert.ok(feat["minecraft:ore_feature"].replace_rules[0].may_replace.includes("minecraft:stone"));
  const base = JSON.parse(dec(BPF("feature_rules/ore_ore.json")))["minecraft:feature_rules"];
  assert.deepEqual(base.distribution.y.extent, [-64, 320]);
  const peak = JSON.parse(dec(BPF("feature_rules/ore_ore_peak.json")))["minecraft:feature_rules"];
  assert.equal(peak.distribution.y.distribution, "triangle");
  assert.deepEqual(peak.distribution.y.extent, [-31, 1]);
  assert.equal(r.warnings.filter((w) => /random_block|not recognized/.test(w)).length, 0);
});

test("random_block: any = rata, di luar dunia dipindah dengan peringatan, nilai salah ditolak", async () => {
  const a = await HX.translate("{block\n    name_tag:ore\n    random_block:any\n}\n", { name: "a" });
  assert.ok(!a.files.some((f) => f.path.endsWith("ore_ore_peak.json")));
  const b = await HX.translate("{block\n    name_tag:ore\n    random_block:999\n}\n", { name: "b" });
  assert.ok(b.warnings.some((w) => /outside the world height/.test(w)));
  assert.deepEqual(JSON.parse(dec(b.files.find((f) => f.path.endsWith("feature_rules/ore_ore_peak.json"))))["minecraft:feature_rules"].distribution.y.extent, [304, 320]);
  await assert.rejects(HX.translate("{block\n    name_tag:ore\n    random_block:dalam\n}\n", {}), (e) => e.name === "HxError");
});

test("huruf pertama baris dikapitalkan otomatis oleh keyboard (Name_tag:, Random_block:, If(, {Item) tetap diterima", async () => {
  const r = await HX.translate("{Block\nName_tag:ore\nHardness:3\nRandom_block:-15\n}\n\n{Item\nName_tag:bijih\n}\n\nIf(ore == destroy){\nItem_drop:bijih\n}\n", { name: "kap" });
  assert.ok(r.files.some((f) => f.path.endsWith("feature_rules/ore_ore.json")));
  assert.equal(r.warnings.filter((w) => /not recognized|random_block/.test(w)).length, 0);
});

/* ---------- UV mapping blok: satu png tata letak UV dilipat jadi kubus ---------- */
const uvRun = async (w, h, extra = "", nuke = false) => {
  const img = HX.pngSolid(w, h, [10, 200, 90]);
  return HX.translate("{Block\nName_tag:ore\nModels://:2611210009\n" + extra + "}\n" + (nuke ? "\nif(flint_and_steel == ore){\nwait:2 second\nboom:on\n}\n" : ""), { name: "uv", fetchAsset: async () => img });
};
const uvGeo = (r) => J(r, r.files.find((f) => /models\/blocks\/ore\.geo\.json$/.test(f.path)).path)["minecraft:geometry"][0];
test("UV mapping 4:2 (kotak Blockbench): dilipat jadi kubus dengan UV per sisi", async () => {
  const r = await uvRun(64, 32);
  const g = uvGeo(r), uv = g.bones[0].cubes[0].uv;
  assert.deepEqual([g.description.texture_width, g.description.texture_height], [64, 32]);
  assert.deepEqual(uv.north, { uv: [16, 16], uv_size: [16, 16] });
  assert.deepEqual(uv.east.uv, [0, 16]); assert.deepEqual(uv.west.uv, [32, 16]); assert.deepEqual(uv.south.uv, [48, 16]);
  assert.deepEqual(uv.up, { uv: [32, 16], uv_size: [-16, -16] });
  assert.deepEqual(uv.down, { uv: [48, 0], uv_size: [-16, 16] });
  const bk = r.files.find((f) => /blocks\/ore\.json$/.test(f.path) && !/models|textures|loot/.test(f.path));
  assert.equal(JSON.parse(dec(bk))["minecraft:block"].components["minecraft:geometry"], "geometry.hx_ore");
  assert.equal(r.warnings.filter((w) => /square|64x64/.test(w)).length, 0);
});
test("UV mapping 4:3 (salib) dan bukan UV (persegi / uv_mapping:off) tetap satu gambar", async () => {
  const c = uvGeo(await uvRun(64, 48)).bones[0].cubes[0].uv;
  assert.deepEqual(c.down.uv, [32, 48]); assert.deepEqual(c.up.uv, [32, 16]);
  for (const r of [await uvRun(32, 32), await uvRun(64, 32, "uv_mapping:off\n")]) {
    assert.ok(!r.files.some((f) => /models\/blocks\/ore\.geo\.json$/.test(f.path)));
    const b = JSON.parse(dec(r.files.find((f) => /blocks\/ore\.json$/.test(f.path) && !/models|textures|loot/.test(f.path))));
    assert.equal(b["minecraft:block"].components["minecraft:geometry"], "minecraft:geometry.full_block");
  }
});

test("UV mapping mob: salib 4:3 otomatis jadi kubus; 2:1 hanya dengan shape:cube (kalau tidak = skin lama)", async () => {
  const run = (w, h, extra = "") => HX.translate("{mob\nname_tag:kotak\nmodels://:2611210009\n" + extra + "}\n", { name: "m", fetchAsset: async () => HX.pngSolid(w, h, [90, 20, 20]) });
  const geoOf = (r) => J(r, r.files.find((f) => /models\/entity\/kotak\.geo\.json$/.test(f.path)).path)["minecraft:geometry"][0];
  const a = geoOf(await run(64, 48)); assert.deepEqual(a.bones[0].cubes[0].uv.down.uv, [32, 48]); assert.deepEqual(a.bones[0].cubes[0].size, [16, 16, 16]);
  const b = geoOf(await run(64, 32, "shape:cube\n")); assert.deepEqual(b.bones[0].cubes[0].uv.north.uv, [16, 16]);
  assert.ok(geoOf(await run(64, 32)).bones.length > 1, "64x32 tanpa shape tetap skin manusia");
});
