{setup
    version_minecraft_support:26.10 and 26.50
    version_mod:1.0.0
    description:Airplane Mod created by Fadhil Badhillah and Nava x team
    icon_mod://:2611170005
}

{asset
    name_tag:airplane_model
    models://:2611170001
}

{asset
    name_tag:airplane_animation
    animation-true-start://:2611170003
}

{mob_netral
    name_tag:airplane
    models://:2611170001
    fly:on
    move:off
    lead:none
    hp:200 hp
    seat_count:1
    seat_position:0, 1.2, 0
}

{item
    name_tag:airplane_egg,
    models://:2611170006,
    icon_item://:2611170004,
    menu_creative:on,
    +give:airplane_egg,
}

{item
    name_tag:wooden_item,
    crafting:1, oak_planks
    crafting:2, oak_planks
    crafting:4, oak_planks
}

{item
    name_tag:super_sword,
    +give:super_sword,
    menu_creative:off,
    damage:+20,
    hp_item:500 hp,
}

[
    if(airplane_egg == right_click){
        spawn:airplane
    }
]

[
    if(airplane == flaying){
        animation-true-start://:2611170003
    }

    if(user == jumpht){
        animation:cancel
    }
]

[
    if(user == sit){
        control:w, and look_up flying
    }

    if(user == right_click){
        sit
    }else{
        stand
    }
]

{costum
    name_user:fadhil
}

[
    if(fadhil == host){
        mode:creative
    }
]
