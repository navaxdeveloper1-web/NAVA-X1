import test from "node:test";
import assert from "node:assert/strict";

// toko palsu mirip @netlify/blobs (set dengan onlyIfNew, getMetadata, get, setJSON)
const stores = {};
globalThis.__xaStore = async n => {
  const m = (stores[n] ??= new Map());
  return {
    async get(k, o) { const v = m.get(k); if (!v) return null; if (o && o.type === "json") return JSON.parse(v.d.toString()); if (o && o.type === "arrayBuffer") return v.d; return v.d.toString(); },
    async getMetadata(k) { const v = m.get(k); return v ? { metadata: v.meta } : null; },
    async set(k, d, o = {}) { if (o.onlyIfNew && m.has(k)) return { modified: false }; m.set(k, { d: Buffer.isBuffer(d) ? d : Buffer.from(String(d)), meta: o.metadata }); return { modified: true }; },
    async setJSON(k, d) { m.set(k, { d: Buffer.from(JSON.stringify(d)) }); },
  };
};
process.env.XA_SECRET = "tes";
const { default: h } = await import("../netlify/functions/auth.mjs");
const reg = async e => (await (await h(new Request("http://x/api/auth", { method: "POST", body: JSON.stringify({ a: "register", email: e, password: "password123" }) }))).json()).token;
const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 13, 10, 26, 10]), Buffer.alloc(20)]);
const up = (tok, name, body) => h(new Request("http://x/api/asset", { method: "POST", headers: { authorization: "Bearer " + tok, "x-asset-name": encodeURIComponent(name) }, body }));
const day = new Date(Date.now() + 7 * 36e5).toISOString().slice(2, 10).replace(/-/g, "");

test("kode memakai tanggal WIB dan urut 0001, 0002", async () => {
  const t = await reg("a@b.co");
  const a = await (await up(t, "x.png", png)).json(), b = await (await up(t, "y.png", png)).json();
  assert.equal(a.code, "//:" + day + "0001"); assert.equal(b.code, "//:" + day + "0002");
});
test("reset ke 0001 saat tanggal berbeda", async () => {
  const t = await reg("c@d.co"), real = Date.now.bind(Date);
  Date.now = () => real() + 864e5;
  try { const r = await (await up(t, "z.png", png)).json(); assert.match(r.code, /^\/\/:\d{6}0001$/); assert.notEqual(r.code, "//:" + day + "0001"); } finally { Date.now = real; }
});
test("unduh publik lewat kode dengan atau tanpa //:", async () => {
  for (const c of [day + "0001", "//:" + day + "0001"]) {
    const r = await h(new Request("http://x/api/asset?code=" + encodeURIComponent(c)));
    assert.equal(r.status, 200); assert.equal(r.headers.get("content-type"), "image/png"); assert.equal(Buffer.from(await r.arrayBuffer()).length, png.length);
  }
  assert.equal((await h(new Request("http://x/api/asset?code=2610169999"))).status, 404);
  assert.equal((await h(new Request("http://x/api/asset?code=abc"))).status, 400);
});
test("tamu ditolak, ekstensi dan isi palsu ditolak, glb diterima", async () => {
  assert.equal((await up("", "x.png", png)).status, 401);
  const t = await reg("e@f.co");
  assert.equal((await up(t, "x.exe", png)).status, 400);
  assert.equal((await up(t, "x.png", Buffer.from("<script>alert(1)</script>"))).status, 400);
  assert.equal((await up(t, "x.svg", Buffer.from("<svg/>"))).status, 400);
  const g = await up(t, "m.glb", Buffer.concat([Buffer.from("glTF"), Buffer.alloc(20)]));
  assert.equal(g.status, 200);
  const r = await h(new Request("http://x/api/asset?code=" + (await g.json()).code));
  assert.equal(r.headers.get("content-type"), "model/gltf-binary");
});
test("daftar aset milik sendiri", async () => {
  const t = await reg("g@h.co"); await up(t, "q.png", png);
  const l = await (await h(new Request("http://x/api/asset?list=1", { headers: { authorization: "Bearer " + t } }))).json();
  assert.equal(l.assets.length, 1); assert.equal(l.assets[0].name, "q.png");
});

test("json diterima hanya bila berisi model atau animasi Bedrock", async () => {
  const t = await reg("hx@b.co");
  const geo = Buffer.from(JSON.stringify({ format_version: "1.12.0", "minecraft:geometry": [{}] })), bad = Buffer.from('{"a":1}');
  assert.equal((await up(t, "m.geo.json", geo)).status, 200);
  assert.equal((await up(t, "x.json", bad)).status, 400);
});
