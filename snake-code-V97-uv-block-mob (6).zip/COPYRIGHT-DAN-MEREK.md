# Hak Cipta dan Merek SNAKE

Berlaku untuk bahasa pemrograman SNAKE, editor SNAKE Code, dan dokumentasinya.

## 1. Hak cipta
Hak Cipta (c) 2026 Fadhil (pembuat SNAKE). Kontak: fadhilbafhillah@gmail.com

Hak cipta ini mencakup:
- kode sumber editor dan interpreter (`index.html`, `netlify/functions/auth.mjs`);
- dokumentasi (`README.md`, folder `docs/`);
- rancangan dan penulisan sintaks bahasa SNAKE, termasuk SNAKE Basic dan SNAKE Clone High Advance (C), yang sepenuhnya dibuat oleh pembuat SNAKE sebagai ide dan rancangan asli. Yang dilindungi hak cipta adalah wujud tertulisnya (spesifikasi, dokumentasi, kode), bukan ide umum di baliknya.

Pengecualian: logo (`logo.png`) dibuat dengan kecerdasan buatan (AI), sehingga tidak diklaim sebagai ciptaan manusia dan tidak diklaim dilindungi hak cipta. Logo tetap dapat dipakai sebagai tanda merek (lihat bagian 2).

Kecuali ada lisensi tertulis yang menyatakan lain, semua hak dilindungi. Tanpa izin tertulis pembuat, jangan menyalin, mengubah, menjual, atau mendistribusikan ulang bagian-bagian di atas.

Program yang ditulis pengguna dengan bahasa SNAKE adalah milik penggunanya.

## 2. Nama merek
"SNAKE", "SNAKE Code", dan "SNAKE Clone High Advance" dipakai sebagai nama merek bahasa dan editor ini. Nama dan logo yang dipakai sebagai tanda pengenal diklaim sebagai merek tidak terdaftar (TM) milik pembuat SNAKE. Perlindungan merek tidak bergantung pada siapa yang menggambar logo, jadi logo AI tetap bisa berfungsi sebagai merek.

Dilarang tanpa izin tertulis:
- memakai nama atau logo SNAKE untuk produk, bahasa, aplikasi, atau layanan lain;
- memakai nama atau logo SNAKE dengan cara yang membuat orang mengira produk itu resmi atau didukung pembuat SNAKE;
- memakai nama yang mirip sehingga membingungkan (misalnya "SNAKE Code Pro" oleh pihak lain).

Boleh tanpa izin:
- menyebut nama SNAKE secara wajar untuk menjelaskan, mengulas, atau mengajarkan bahasa ini;
- membuat dan membagikan program atau library yang ditulis dalam bahasa SNAKE.

## 3. Catatan hukum
- Dokumen ini adalah pernyataan kepemilikan, bukan merek terdaftar. Perlindungan merek yang kuat di Indonesia diperoleh lewat pendaftaran ke DJKI (Direktorat Jenderal Kekayaan Intelektual, pdki-indonesia.dgip.go.id). Tanda (R) baru boleh dipakai setelah merek terdaftar.
- Hak cipta di Indonesia mensyaratkan ciptaan dari manusia, karena itu logo AI tidak diklaim. Bagian yang diketik, dirancang, dan diedit manusia tetap dilindungi. Hak cipta timbul otomatis saat ciptaan diwujudkan (UU No. 28 Tahun 2014). Pencatatan ke DJKI bersifat opsional tetapi berguna sebagai bukti.
- "Snake" adalah kata umum dan banyak produk memakai nama serupa. Sebelum mendaftar, lakukan pengecekan merek yang sudah ada dan pertimbangkan konsultasi dengan konsultan HKI atau pengacara.
- Dokumen ini bukan nasihat hukum.
